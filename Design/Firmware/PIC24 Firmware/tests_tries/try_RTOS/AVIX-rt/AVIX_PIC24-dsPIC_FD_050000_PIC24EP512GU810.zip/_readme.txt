
================================================================================
              AVIX DEMO DISTRIBUTION FOR PIC24-dsPIC VERSION 5.0.0
                LICENSE TYPE: FREE (for evaluation purposes only)

       (BUILD AND CONFIGURED FOR THE Microchip PIC24EP512GU810 CONTROLLER)
================================================================================

THE  SOFTWARE  IN  THIS  DISTRIBUTION  IS  SUBJECT TO A FREE LICENSE PROHIBITING
COMMERCIAL  USE. PLEASE READ THE LICENSE AGREEMENT PRESENT IN THE SETUP PROGRAMS
FOR RELEVANT DETAILS.

THE  LIBRARY  IN  THIS  DISTRIBUTION  IS BUILD FOR THE Microchip PIC24EP512GU810
CONTROLLER  AND WILL NOT WORK WITH ANOTHER TYPE. WHEN NEEDING A DISTRIBUTION FOR
A DIFFERENT TYPE OF CONTROLLER, PLEASE PURCHASE A RETAIL DISTRIBUTION OR CONTACT
AVIX-RT  FOR  POSSIBILITIES  TO ACQUIRE A FREE DEMO DISTRIBUTION FOR A DIFFERENT
TYPE OF CONTROLLER.
--------------------------------------------------------------------------------
THIS DIRECTORY CONTAINS:


================================================================================
AVIX_PIC24-dsPICSetup_FD_050000_PIC24EP512GU810.exe:  Setup program for AVIX for
PIC24-dsPIC DEMO Distribution.
--------------------------------------------------------------------------------
This  program  will install AVIX for PIC24-dsPIC on your computer, including all
applicable documentation. For a list of the documentation files, see below.



================================================================================
AVIXPluginMicrochipMplab8x_v0500.exe:  Setup utility for the MPLAB8x RTOS viewer
plug-in
--------------------------------------------------------------------------------
This  program  will  install  the  AVIX  RTOS Viewer plug-in for MPLAB8x on your
computer.  This  plug-in  is  a Microsoft COM (Component Object Model) component
packaged  in  a  windows  DLL. As part of the install process a reference to the
location  where  this DLL is installed is entered in your systems registry. This
is required for the MPLAB development environment to be able to locate this DLL.

With  this  plug-in  comes a user manual which is installed in the directory you
specify  during  the  install  process. Please refer this manual to learn how to
activate the plug-in from MPLAB8x and what kind of information it provides.
================================================================================


The installed documentation consists of the following files:

- AVIX_UserReferenceGuideV050000.pdf:  This  document contains both a User and a
  Reference Guide. The User Guide introduces the AVIX concepts and how these can
  be  used  to  create  applications.  The  Reference  Guide contains a detailed
  description of all AVIX functions and macros.

- AVIX_PIC24-dsPICv050000PortGuideMicrochipMplab.pdf:  This  document contains a
  description of the aspects specific to the AVIX for PIC24-dsPIC port used with
  the  MICROCHIP  MPLAB8x  development environment. The content of this document
  forms an extension to the User and Reference Guide.

- AVIX_ReleaseNotesV050000.pdf:  Description  of new features, fixes and changes
  in this version of AVIX.

- AVIX_Tutorial.pdf:  Description of the tutorial application that is installed.
  This  tutorial  applications  is  useful  to  get started working with AVIX as
  quickly as possible.

- AVIX_ExchangeMechanism.pdf  :  Document  dedicated  to  the Exchange Mechanism
  which  allows  highly  modular application development. This document explains
  the  mechanism  based on a real application development case in a step by step
  introduction.

- AVIX_AtomicSFRManipulation.pdf: User manual of AVIX specific macros for atomic
  bit  operations  on  Special  Function Registers. This is especially important
  when  using  Special Function Registers from multiple threads and/or interrupt
  handlers.
================================================================================

Always feel free to contact AVIX-RT using the contact information below

            .-------------------------------------------------------.
            |                       AVIX-RT                         |
            |-------------------------------------------------------|
            | web:     www.avix-rt.com                              |
            | e-mail:  info@avix-rt.com     (for general inquiries) |
            |          support@avix-rt.com  (for support questions) |
            | phone:   +31(0)615285177                              |
            | address: AVIX-RT                                      |
            |          Maisveld 84                                  |
            |          5236 VC  's-Hertogenbosch                    |
            |          The Netherlands                              |
            `-------------------------------------------------------'


================================================================================
                    AVIX-RT � 2006-2012, All Rights Reserved
================================================================================
