This project intended for the Micro Media Board for PIC24 EP.
It was developed by John Barrat.