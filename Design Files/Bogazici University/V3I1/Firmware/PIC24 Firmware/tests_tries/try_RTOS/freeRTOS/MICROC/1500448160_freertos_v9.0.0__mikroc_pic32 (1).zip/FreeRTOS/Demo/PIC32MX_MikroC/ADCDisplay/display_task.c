// display_task.c

// This file contains the display task, which receives user input,
// and displays it on TFT and LEDs.

// Includes

#include "main.h"
#include "tft_resources.h"

// Preprocessor Constants

#define TFT_BACKGROUND_COLOR  CL_BLACK // TFT background color
#define TFT_LINE_COLOR        CL_WHITE // TFT line color
#define TFT_CENTER_FONT_COLOR CL_WHITE // TFT center font color
#define TFT_HEADER_FONT_COLOR CL_RED   // TFT header font color
#define TFT_FOOTER_FONT_COLOR CL_GRAY  // TFT footer font color

// Memory Declarations

// TFT module connections
char TFT_DataPort at LATE;
sbit TFT_RST at LATD7_bit;
sbit TFT_BLED at LATD2_bit;
sbit TFT_RS at LATD9_bit;
sbit TFT_CS at LATD10_bit;
sbit TFT_RD at LATD5_bit;
sbit TFT_WR at LATD4_bit;
char TFT_DataPort_Direction at TRISE;
sbit TFT_RST_Direction at TRISD7_bit;
sbit TFT_BLED_Direction at TRISD2_bit;
sbit TFT_RS_Direction at TRISD9_bit;
sbit TFT_CS_Direction at TRISD10_bit;
sbit TFT_RD_Direction at TRISD5_bit;
sbit TFT_WR_Direction at TRISD4_bit;

static TDisplayMessage msgBuffer; // Buffer for TFT draw messages

static uint8_t btnTextMsg[30];    // Text message for button
static uint8_t adcTextMsg[30];    // Text message for ADC

// Public Function Definitions

void displayTask(void *pvParameters)
{
    uint8_t btnPressed;    // Pressed button.
    uint8_t oldBtnPressed; // Previously pressed button.
    uint16_t blinkDelay;   // LED blink task blink delay.

    uint16_t adcValue;     // ADC reading.
    uint16_t oldAdcValue;  // Previous ADC reading.

    // Initialize the TFT display.
    TFT_BLED_Direction = 0;
    TFT_Init_ILI9341_8bit(320, 240);
    TFT_BLED = 1;
    TFT_Fill_Screen(TFT_BACKGROUND_COLOR);

    // Draw the initial screen.
    TFT_Set_Brush(1, TFT_BACKGROUND_COLOR, 0, 0, 0, 0);
    TFT_Set_Font(TFT_defaultFont, TFT_BACKGROUND_COLOR, FO_HORIZONTAL);
    TFT_Set_Pen(TFT_LINE_COLOR, 1);
    TFT_Line(20, 220, 300, 220);
    TFT_Line(20,  46, 300,  46);
    TFT_Set_Font(
        &HandelGothic_BT21x22_Regular, TFT_HEADER_FONT_COLOR, FO_HORIZONTAL);
    TFT_Write_Text("FreeRTOS Example", 68, 14);
    TFT_Set_Font(&Verdana12x13_Regular, TFT_FOOTER_FONT_COLOR, FO_HORIZONTAL);
    TFT_Write_Text("EasyPIC Fusion v7", 19, 223);
    TFT_Set_Font(&Verdana12x13_Regular, TFT_HEADER_FONT_COLOR, FO_HORIZONTAL);
    TFT_Write_Text("www.mikroe.com", 200, 223);

    TFT_Set_Font(TFT_defaultFont, TFT_CENTER_FONT_COLOR, FO_HORIZONTAL);
    sprintf(btnTextMsg, "Button pressed:");
    TFT_Write_Text(btnTextMsg, 80, 100);
    sprintf(adcTextMsg, "ADC sample:");
    TFT_Write_Text(adcTextMsg, 104, 120);

    adcTextMsg[0] = 0;
    oldBtnPressed = 0xFF;
    oldAdcValue = 0xFFFF;
    
    // Wait for input data from other tasks, and handle it accordingly.
    while (1)
    {
        // Receive data from the queue.
        xQueueReceive(displayQueueHandle, &msgBuffer, 0xFFFFFFFFU);
        
        switch (msgBuffer.msgType)
        {
            case MSG_BUTTON:
                // Button data.
                btnPressed = msgBuffer.msgData[0];
                if (btnPressed != oldBtnPressed)
                {
                    // Set LED task's blink delay
                    // accorfing to the pressed button.
                    switch (btnPressed)
                    {
                        case 0:
                            blinkDelay = 125; // 125 ms
                            break;
                        case 1:
                            blinkDelay = 250; // 250 ms
                            break;
                        case 2:
                            blinkDelay = 500; // 500 ms
                            break;
                        case 3:
                            blinkDelay = 0;   // no delay
                            break;
                        default:
                            break;
                    }
                    ledBlinkSetBlinkDelay(blinkDelay);
                
                    // Display the number of the pressed button on TFT.
                    TFT_Set_Font(TFT_defaultFont,
                        TFT_BACKGROUND_COLOR, FO_HORIZONTAL);
                    TFT_Write_Text(btnTextMsg, 184, 100);
                    
                    sprintf(btnTextMsg, "%i", (uint16_t)btnPressed);
                    TFT_Set_Font(TFT_defaultFont,
                        TFT_CENTER_FONT_COLOR, FO_HORIZONTAL);
                    TFT_Write_Text(btnTextMsg, 184, 100);
                    
                    oldBtnPressed = btnPressed;
                }
                break;
                
            case MSG_ADC_SAMPLE:
                // ADC sample data.
                adcValue = ((uint16_t)msgBuffer.msgData[1] << 8)
                    + msgBuffer.msgData[0];
                if (adcValue != oldAdcValue)
                {
                    // Set LED task's ADC value.
                    ledBlinkSetAdcValue(adcValue);
                    
                    // Display the sampled ADC value on TFT.
                    TFT_Set_Font(TFT_defaultFont,
                        TFT_BACKGROUND_COLOR, FO_HORIZONTAL);
                    TFT_Write_Text(adcTextMsg, 184, 120);
                    
                    sprintf(adcTextMsg, "%i", adcValue );
                    TFT_Set_Font(TFT_defaultFont,
                        TFT_CENTER_FONT_COLOR, FO_HORIZONTAL);
                    TFT_Write_Text(adcTextMsg, 184, 120);
                    
                    oldAdcValue = adcValue;
                }
                break;
                
            default:
                break;
        }
    }
}