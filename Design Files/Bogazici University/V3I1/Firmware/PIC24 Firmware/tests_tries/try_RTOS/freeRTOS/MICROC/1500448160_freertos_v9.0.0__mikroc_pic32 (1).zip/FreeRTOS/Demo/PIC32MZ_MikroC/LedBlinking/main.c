/*
 * Project name:
     FreeRTOS Led Blinking
 * Copyright:
     (c) Mikroelektronika, 2017.
 * Revision History:
     20170718:
       - Initial release;
 * Description:
     This code demonstrates the use of three tasks
     to simultaneously blink LEDs on several different PORTs.
 * Test configuration:
     MCU:             P32MZ2048EFH144
                      http://ww1.microchip.com/downloads/en/DeviceDoc/60001320D.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 200.000MHz
     Ext. Modules:    None
     SW:              mikroC PRO for PIC32
                      http://www.mikroe.com/mikroc/pic32/
 * NOTES:
     - Turn ON LEDs on PORTB, PORTD, and PORTF at SW15.
 */

// Includes

#include "main.h"

// Public Function Definitions

// Task 1 - Blinks PORTB LEDs.
void task1(void *pvParameters)
{
    // Set PORTB pins as digital output.
    ANSELB = 0;
    TRISB = 0;

    LATB = 0xFFFFFFFF;
    
    // Blink PORTB LEDs with some delay.
    while (1)
    {
        vTaskDelay(pdMS_TO_TICKS(250));
        LATB = ~PORTB;
    }
}

// Task 2 - Blinks PORTD LEDs.
void task2(void *pvParameters)
{
    // Set PORTD pins as digital output.
    ANSELD = 0;
    TRISD = 0;

    LATD = 0xFFFFFFFF;

    // Blink PORTD LEDs with some delay.
    while (1)
    {
        vTaskDelay(pdMS_TO_TICKS(500));
        LATD = ~PORTD;
    }
}

// Task 3 - Blinks PORTF LEDs.
void task3(void *pvParameters)
{
    // Set PORTF pins as digital output.
    ANSELF = 0;
    TRISF = 0;

    LATF = 0xFFFFFFFF;

    // Blink PORTF LEDs with some delay.
    while (1)
    {
        vTaskDelay(pdMS_TO_TICKS(1000));
        LATF = ~PORTF;
    }
}

// Main function, which creates the tasks and starts the scheduler.
void main()
{
    // Disable shadow register context saving for interrupt level 1.
    PRISS &= 0xFFFFFF0F;

    // Create task 1.
    xTaskCreate(
        (TaskFunction_t)task1,
        "Task 1",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // Create task 2.
    xTaskCreate(
        (TaskFunction_t)task2,
        "Task 2",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // Create task 3.
    xTaskCreate(
        (TaskFunction_t)task3,
        "Task 3",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // Start the RTOS scheduler.
    vTaskStartScheduler();
    
    // Will never reach here.
    while (1);
}