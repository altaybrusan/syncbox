// init_task.c

// This file contains the init task
// which initializes structures and other tasks.

// Includes

#include "main.h"

// Memory Declarations

QueueHandle_t     displayQueueHandle; // TFT draw queue handle
SemaphoreHandle_t ledBlinkSemHandle;  // LED blink queue handle

// Public Function Definitions

// Initializes structures and other tasks.
// Should be the only task initialized in main.
void initTask(void *pvParameters)
{
    // Configure AN pins as digital I/O, PORTB.B0 as analog.
    AD1PCFG = 0xFFFE;
    // Disable JTAG port.
    JTAGEN_bit = 0;
    
    // Create queues.
    displayQueueHandle =
        xQueueCreate(MSG_QUEUE_LENGTH, sizeof(TDisplayMessage));
    vQueueAddToRegistry(displayQueueHandle, "Display Queue" );
        
    ledBlinkSemHandle = xSemaphoreCreateMutex();
    vQueueAddToRegistry(ledBlinkSemHandle, "LED Semaphore" );
    
    // Initialize tasks.
    
    // TFT task
    xTaskCreate(
        (TaskFunction_t)displayTask,
        "TFT Draw Task",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // LED task
    xTaskCreate(
        (TaskFunction_t)ledBlinkTask,
        "LED Blink Task",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // Button task
    xTaskCreate(
        (TaskFunction_t)buttonTask,
        "Button Task",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // ADC task
    xTaskCreate(
        (TaskFunction_t)adcReadTask,
        "ADC Read Task",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // This task has served its purpose. Delete it.
    vTaskDelete(NULL);
}