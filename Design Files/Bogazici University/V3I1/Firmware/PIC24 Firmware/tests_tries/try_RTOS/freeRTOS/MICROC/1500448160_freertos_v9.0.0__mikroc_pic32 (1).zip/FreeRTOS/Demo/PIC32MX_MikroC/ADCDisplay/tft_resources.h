// tft_resources.h

// Declarations of some TFT resources.

#ifndef _tft_resources_h_
#define _tft_resources_h_

const code char HandelGothic_BT21x22_Regular[];
const code char Verdana12x13_Regular[];
const code char Tahoma15x16_Bold[];

#endif