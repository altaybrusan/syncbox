In order to successfully compile the examples, you need to enable case sensitivity in mikroC PRO for PIC32 compiler.

First, open the Options window by selecting Tools -> Options.
Then open the Output tab on the left, and select Output Settings.
Finally, in Compiler options, check Case sensitive.

When using interrupts, it can be useful to place portISR_ENTRY() at the beginning of an ISR,
and portISR_EXIT() at the end of an ISR (or any other place where there is an explicit return from the function).
While using there macros, it will be possible to detect
that a non ISR RTOS function was called from an ISR, which is an error.
You can omit these calls if you are confident that you will not make such mistakes in your code.