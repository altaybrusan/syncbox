/*
 * Project name:
     FreeRTOS ADC Display
 * Copyright:
     (c) Mikroelektronika, 2017.
 * Revision History:
     20170718:
       - Initial release;
 * Description:
     This code uses buttons and an analog input for inputting user data,
     and shows the data on TFT display and LEDs.

     TFT will constantly be displaying the ADC input,
     as well as indicate which button was pressed.
     PORTA and PORTC LEDs will be displaying the value of the ADC input as well,
     and will be blinking with a frequency
     that can be adjusted by pressing the appropriate buttons.

     The on-board potentiometer can be used to change the value
     of the ADC input. Buttons RF4, RF5, RF12, and RF13 can be used
     to change the blinking frequency of the LEDs that display the ADC input.
 * Test configuration:
     MCU:             P32MX795F512L
                      http://ww1.microchip.com/downloads/en/DeviceDoc/61156F.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.0000MHz
     Ext. Modules:    EasyTFT display
     SW:              mikroC PRO for PIC32
                      http://www.mikroe.com/mikroc/pic32/
 * NOTES:
     - Connect jumper J8 to RB0 (ADC channel 0 input).
     - Enable button press level SW10.6 for PORTF.
     - Pull down on PORTF pins 4, 5, 12, and 13.
     - Turn on LEDs on PORTA&C at SW15.
     - Turn ON TFT BCK LIGHT switch at SW11.1.
 */

// Includes

#include "main.h"

// Public Function Definitions

// Main function, which creates the tasks and starts the scheduler.
void main()
{
    // Create init task.
    xTaskCreate(
        (TaskFunction_t)initTask,
        "Init Task",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // Start the RTOS scheduler.
    vTaskStartScheduler();

    // Will never reach here.
    while (1);
}