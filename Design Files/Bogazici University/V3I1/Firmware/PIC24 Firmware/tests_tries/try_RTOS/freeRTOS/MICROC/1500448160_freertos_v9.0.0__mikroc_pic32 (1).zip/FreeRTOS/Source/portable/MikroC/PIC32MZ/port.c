/*
    FreeRTOS V9.0.1 - Copyright (C) 2017 Real Time Engineers Ltd.
    All rights reserved

    VISIT http://www.FreeRTOS.org TO ENSURE YOU ARE USING THE LATEST VERSION.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation >>>> AND MODIFIED BY <<<< the FreeRTOS exception.

    ***************************************************************************
    >>!   NOTE: The modification to the GPL is included to allow you to     !<<
    >>!   distribute a combined work that includes FreeRTOS without being   !<<
    >>!   obliged to provide the source code for proprietary components     !<<
    >>!   outside of the FreeRTOS kernel.                                   !<<
    ***************************************************************************

    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT ANY
    WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
    FOR A PARTICULAR PURPOSE.  Full license text is available on the following
    link: http://www.freertos.org/a00114.html

    ***************************************************************************
     *                                                                       *
     *    FreeRTOS provides completely free yet professionally developed,    *
     *    robust, strictly quality controlled, supported, and cross          *
     *    platform software that is more than just the market leader, it     *
     *    is the industry's de facto standard.                               *
     *                                                                       *
     *    Help yourself get started quickly while simultaneously helping     *
     *    to support the FreeRTOS project by purchasing a FreeRTOS           *
     *    tutorial book, reference manual, or both:                          *
     *    http://www.FreeRTOS.org/Documentation                              *
     *                                                                       *
    ***************************************************************************

    http://www.FreeRTOS.org/FAQHelp.html - Having a problem?  Start by reading
    the FAQ page "My application does not run, what could be wrong?".  Have you
    defined configASSERT()?

    http://www.FreeRTOS.org/support - In return for receiving this top quality
    embedded software for free we request you assist our global community by
    participating in the support forum.

    http://www.FreeRTOS.org/training - Investing in training allows your team to
    be as productive as possible as early as possible.  Now you can receive
    FreeRTOS training directly from Richard Barry, CEO of Real Time Engineers
    Ltd, and the world's leading authority on the world's leading RTOS.

    http://www.FreeRTOS.org/plus - A selection of FreeRTOS ecosystem products,
    including FreeRTOS+Trace - an indispensable productivity tool, a DOS
    compatible FAT file system, and our tiny thread aware UDP/IP stack.

    http://www.FreeRTOS.org/labs - Where new FreeRTOS products go to incubate.
    Come and try FreeRTOS+TCP, our new open source TCP/IP stack for FreeRTOS.

    http://www.OpenRTOS.com - Real Time Engineers ltd. license FreeRTOS to High
    Integrity Systems ltd. to sell under the OpenRTOS brand.  Low cost OpenRTOS
    licenses offer ticketed support, indemnification and commercial middleware.

    http://www.SafeRTOS.com - High Integrity Systems also provide a safety
    engineered and independently SIL3 certified version for use in safety and
    mission critical applications that require provable dependability.

    1 tab == 4 spaces!
*/

//-----------------------------------------------------------
// Implementation of functions defined in portable.h for the PIC32MX port.
//-----------------------------------------------------------

// Scheduler include files.
#include "FreeRTOS.h"
#include "task.h"

#if ((configMAX_SYSCALL_INTERRUPT_PRIORITY >= 0x7) || (configMAX_SYSCALL_INTERRUPT_PRIORITY == 0))
    #error configMAX_SYSCALL_INTERRUPT_PRIORITY must be less than 7 and greater than 0.
#endif

// Hardware specifics.
#define portTIMER_PRESCALE       8
#define portPRESCALE_BITS        1

// Bits within various registers.
#define portIE_BIT               (0x00000001)
#define portEXL_BIT              (0x00000002)
// Allow access to DSP instructions.
#define portMX_BIT               (0x01000000)
// Enable CP1 for parts with hardware.
#define portCU1_BIT              (0x20000000)
// Enable 64 bit floating point registers.
#define portFR_BIT               (0x04000000)

// Bits within the CAUSE register.
#define portCORE_SW_0            (0x00000100)
#define portCORE_SW_1            (0x00000200)

// The EXL bit is set to ensure interrupts do not occur
// while the context of the first task is being restored.
#if (__MICROAPTIV_FP__ == 1)
    #define portINITIAL_SR                                                     \
        (portIE_BIT | portEXL_BIT | portMX_BIT | portFR_BIT | portCU1_BIT)
#else
    #define portINITIAL_SR (portIE_BIT | portEXL_BIT | portMX_BIT)
#endif

// The initial value to store into the FPU status and control register.
// This is only used on parts that support a hardware FPU.
#define portINITIAL_FPSCR        (0x1000000) // High perf on denormal ops.

/*
By default port.c generates its tick interrupt from TIMER1.  The user can
override this behaviour by:
    1: Providing their own implementation of vApplicationSetupTickTimerInterrupt(),
       which is the function that configures the timer.  The function is defined
       as a weak symbol in this file so if the same function name is used in the
       application code then the version in the application code will be linked
       into the application in preference to the version defined in this file.
    2: Define configTICK_INTERRUPT_VECTOR to the vector number of the timer used
       to generate the tick interrupt.  For example, when timer 1 is used then
       configTICK_INTERRUPT_VECTOR is set to _TIMER_1_VECTOR.
       configTICK_INTERRUPT_VECTOR should be defined in FreeRTOSConfig.h.
    3: Define configCLEAR_TICK_TIMER_INTERRUPT() to clear the interrupt in the
       timer used to generate the tick interrupt.  For example, when timer 1 is
       used configCLEAR_TICK_TIMER_INTERRUPT() is defined to
       IFS0CLRbits.T1IF = 0x1.
*/
#ifndef configTICK_INTERRUPT_VECTOR
    #define configTICK_INTERRUPT_VECTOR _TIMER_1_VECTOR
    #define configCLEAR_TICK_TIMER_INTERRUPT() IFS0CLRbits.T1IF = 0x1
#else
    #ifndef configCLEAR_TICK_TIMER_INTERRUPT
        #error If configTICK_INTERRUPT_VECTOR is defined in application code then configCLEAR_TICK_TIMER_INTERRUPT must also be defined in application code.
    #endif
#endif

// Let the user override the pre-loading of the initial RA
// with the address of prvTaskExitError()
// in case it messes up unwinding of the stack in the debugger
// - in which case configTASK_RETURN_ADDRESS can be defined as 0 (NULL).
#ifdef configTASK_RETURN_ADDRESS
    #define portTASK_RETURN_ADDRESS configTASK_RETURN_ADDRESS
#else
    #define portTASK_RETURN_ADDRESS prvTaskExitError
#endif

// Set configCHECK_FOR_STACK_OVERFLOW to 3 to add ISR stack checking to task
// stack checking.  A problem in the ISR stack will trigger an assert, not call
// the stack overflow hook function (because the stack overflow hook is specific
// to a task stack, not the ISR stack).
#if (configCHECK_FOR_STACK_OVERFLOW > 2)

    // Don't use 0xa5 as the stack fill bytes as that is used by the kernel for
    // the task stacks, and so will legitimately appear in many positions within
    // the ISR stack.
    #define portISR_STACK_FILL_BYTE        0xEE

    static const uint8_t ucExpectedStackBytes[] =
    {
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE
    };

    #define portCHECK_ISR_STACK()                                              \
        configASSERT((memcmp((void *)xISRStack, (void *) ucExpectedStackBytes, \
        sizeof(ucExpectedStackBytes)) == 0))
#else
    // Define the function away.
    #define portCHECK_ISR_STACK()
#endif // configCHECK_FOR_STACK_OVERFLOW > 2

//-----------------------------------------------------------

#define portCONTEXT_SIZE                  164
#define portSTATUS_STACK_LOCATION         160
#define portEPC_STACK_LOCATION            156
#define portTASK_HAS_FPU_STACK_LOCATION   0
#define portFPU_CONTEXT_SIZE              264
#define portFPCSR_STACK_LOCATION          0
#define portFPCSR_STACK_LOCATION_ABSOLUTE 164

//-----------------------------------------------------------

// The tick interrupt handler that increases the tick count
// and checks if context switching is required.
// The interrupt priority is set in vApplicationSetupTickTimerInterrupt().
extern void vPortTickInterruptHandler();

// The software interrupt handler that performs the yield.
// The interrupt priority is set in xPortStartScheduler().
void vPortYieldISR();

// Used to catch tasks that attempt to return from their implementing function.
static void prvTaskExitError();

//-----------------------------------------------------------

// From tasks.c.
extern void *pxCurrentTCB;

// Task function pointer for pragma indfuncall.
void (*vTaskFunction)(void*);

// Records the interrupt nesting depth.
volatile UBaseType_t uxInterruptNesting = 0x00;

// Stores the task stack pointer when a switch is made to use the system stack.
UBaseType_t uxSavedTaskStackPointer = 0;

// The stack used by interrupt service routines that cause a context switch.
StackType_t xISRStack[configISR_STACK_SIZE] = { 0 };

// The top of stack value ensures there is enough space to store 6 registers on
// the callers stack, as some functions seem to want to do this.
// 8 byte alignment is required to allow double word floating point stack pushes
// generated by the compiler.
const StackType_t * const xISRStackTop =
    &(xISRStack[(configISR_STACK_SIZE & ~portBYTE_ALIGNMENT_MASK) - 8]);

// Saved as part of the task context.
// Set to pdFALSE if the task does not require an FPU context.
#if (__MICROAPTIV_FP__ == 1) && (configUSE_TASK_FPU_SUPPORT == 1)
    uint32_t ulTaskHasFPUContext = 0;
#endif

//-----------------------------------------------------------

// See header file for description.
StackType_t *pxPortInitialiseStack(
    StackType_t *pxTopOfStack, TaskFunction_t pxCode, void *pvParameters)
{
    *pxTopOfStack = (StackType_t) CP0_GET(CP0_CAUSE);

    // CP0_STATUS
    pxTopOfStack--;
    *pxTopOfStack = (StackType_t) portINITIAL_SR;

    // CP0_EPC
    pxTopOfStack--;
    *pxTopOfStack = (StackType_t) pxCode;

    // DSPControl
    pxTopOfStack--;
    *pxTopOfStack = (StackType_t) 0x00000000;

    // Space for AC1 - AC3.
    pxTopOfStack -= 6;                            

    // R31 (return address)
    pxTopOfStack--;
    *pxTopOfStack = (StackType_t) portTASK_RETURN_ADDRESS;

    // R25 - Parameter to pass in.
    pxTopOfStack -= 5;
    *pxTopOfStack = (StackType_t) pvParameters;

    // Space for registers.
    pxTopOfStack -= 25;

    // FPU context saving is disabled by default.
    pxTopOfStack--;
    *pxTopOfStack = (StackType_t) pdFALSE;

    return pxTopOfStack;
}
//-----------------------------------------------------------

#pragma funcall pxPortInitialiseStack prvTaskExitError

static void prvTaskExitError()
{
    // A function that implements a task must not exit or attempt to return to
    // its caller as there is nothing to return to.  If a task wants to exit it
    // should instead call vTaskDelete(NULL).

    // Artificially force an assert() to be triggered if configASSERT() is
    // defined, then stop here so application writers can catch the error.
    configASSERT(uxSavedTaskStackPointer == 0UL);
    portDISABLE_INTERRUPTS();
    while (1);
}
//-----------------------------------------------------------

// Setup a timer for a regular tick.  This function uses peripheral timer 1.
// The function is declared weak so an application writer can use a different
// timer by redefining this implementation.  If a different timer is used then
// configTICK_INTERRUPT_VECTOR must also be defined in FreeRTOSConfig.h to
// ensure the RTOS provided tick interrupt handler is installed on the correct
// vector number.  When Timer 1 is used the vector number is defined as
// _TIMER_1_VECTOR.
void vApplicationSetupTickTimerInterrupt()
{
    const uint32_t ulCompareMatch =
        ((configPERIPHERAL_CLOCK_HZ / portTIMER_PRESCALE)
        / configTICK_RATE_HZ ) - 1UL;

    T1CON = 0x0000;
    T1CONbits.TCKPS = portPRESCALE_BITS;
    PR1 = ulCompareMatch;
    IPC1bits.T1IP = configKERNEL_INTERRUPT_PRIORITY;

    // Clear the interrupt as a starting condition.
    IFS0bits.T1IF = 0;

    // Enable the interrupt.
    IEC0bits.T1IE = 1;

    // Start the timer.
    T1CONbits.TON = 1;
}
//-----------------------------------------------------------

void vPortStartFirstTask()
{
    // Simply restore the context of the highest priority task that has been
    // created so far.
    asm {
        // Get the top of stack of the first task to execute.
        LW SP, Offset(_pxCurrentTCB)(GP)
        LW SP, (SP)
        
        // Restore only the necessary registers.
        LW    R25, 104(SP) // Task argument.
        LW    R31, 124(SP) // Task return address.
        LW    R4,  portEPC_STACK_LOCATION(SP) // CP0_EPC
        LW    R5,  portSTATUS_STACK_LOCATION(SP) // CP0_STATUS
        /*
        // Restore DSPControl.
        LW    R6,  152(SP)
        WRDSP R6
        */

        #if (__MICROAPTIV_FP__ == 1) && (configUSE_TASK_FPU_SUPPORT == 1)
            // Restore ulTaskHasFPUContext.
            LW    R6,  0(SP)
            SW    R6,  Offset(_ulTaskHasFPUContext)(GP)
        #endif // __MICROAPTIV_FP__ == 1

        // Update the stack pointer.
        ADDIU SP, SP, portCONTEXT_SIZE
        
        // Set CP0_STATUS and CP0_EPC values.
        MTC0 R5, _CP0_STATUS
        MTC0 R4, _CP0_EPC
        
        // Simulate a return from exception.
        ERET
        NOP
    }
}
//-----------------------------------------------------------

void vPortEndScheduler()
{
    // Not implemented in ports where there is nothing to return to.
    // Artificially force an assert.
    configASSERT(uxInterruptNesting == 1000UL);
}
//-----------------------------------------------------------

BaseType_t xPortStartScheduler()
{
    #if (configCHECK_FOR_STACK_OVERFLOW > 2)
    {
        // Fill the ISR stack to make it easy to assess how much is being used.
        memset((void *)xISRStack, portISR_STACK_FILL_BYTE, sizeof(xISRStack));
    }
    #endif // configCHECK_FOR_STACK_OVERFLOW > 2

    // Clear the software interrupt flag.
    IFS0CLRbits.CS0IF = 0x1;

    // Set software timer priority.
    IPC0CLRbits.CS0IP = 0x7;
    IPC0SETbits.CS0IP = configKERNEL_INTERRUPT_PRIORITY;

    // Enable software interrupt.
    IEC0CLRbits.CS0IE = 0x1;
    IEC0SETbits.CS0IE = 0x1;

    // Setup the timer to generate the tick.
    // Interrupts will have been disabled by the time we get here.
    vApplicationSetupTickTimerInterrupt();

    // Kick off the highest priority task that has been created so far.
    // Its stack location is loaded into uxSavedTaskStackPointer.
    uxSavedTaskStackPointer = *(UBaseType_t *)pxCurrentTCB;
    vPortStartFirstTask();

    // Should never get here as the tasks will now be executing! 
    // Call the task exit error function just in case.
    prvTaskExitError();

    return pdFALSE;
}

// Pragma to enable linking of functions that are not explicitly called,
// i.e. tasks.
#pragma indfuncall xPortStartScheduler vTaskFunction

//-----------------------------------------------------------

void vPortIncrementTick()
{
    UBaseType_t uxSavedStatus;

    uxSavedStatus = uxPortSetInterruptMaskFromISR();
    {
        if (xTaskIncrementTick() != pdFALSE)
        {
            // Pend a context switch.
            CP0_SET(CP0_CAUSE, CP0_GET(CP0_CAUSE) | portCORE_SW_0);
        }
    }
    vPortClearInterruptMaskFromISR(uxSavedStatus);

    // Look for the ISR stack getting near or past its limit.
    portCHECK_ISR_STACK();

    // Clear timer interrupt.
    configCLEAR_TICK_TIMER_INTERRUPT();
}
//-----------------------------------------------------------

UBaseType_t uxPortSetInterruptMaskFromISR()
{
    UBaseType_t uxSavedStatusRegister;

    DisableInterrupts();
    uxSavedStatusRegister = CP0_GET(CP0_STATUS) | 0x01;
    // This clears the IPL bits, then sets them to
    // configMAX_SYSCALL_INTERRUPT_PRIORITY.  This function should not be called
    // from an interrupt that has a priority above
    // configMAX_SYSCALL_INTERRUPT_PRIORITY so, when used correctly, the action
    // can only result in the IPL being unchanged or raised, and therefore never
    // lowered.
    CP0_SET(CP0_STATUS, (uxSavedStatusRegister & (~portALL_IPL_BITS)) |
        (configMAX_SYSCALL_INTERRUPT_PRIORITY << portIPL_SHIFT));

    return uxSavedStatusRegister;
}
//-----------------------------------------------------------

void vPortClearInterruptMaskFromISR(UBaseType_t uxSavedStatusRegister)
{
    CP0_SET(CP0_STATUS, uxSavedStatusRegister);
}
//-----------------------------------------------------------

#if (__MICROAPTIV_FP__ == 1) && (configUSE_TASK_FPU_SUPPORT == 1)

    void vPortTaskUsesFPU()
    {
        portENTER_CRITICAL();
        
        // Initialize the floating point status register in CP1.
        asm ADDIU SP, SP, -4
        asm SW    R4, 0(SP)
        R4 = portINITIAL_FPSCR;
        asm CTC1  R4, S31
        asm LW    R4, 0(SP)
        asm ADDIU SP, SP, 4

        // A task is registering the fact that it needs an FPU context.
        // Set the FPU flag (saved as part of the task context).
        ulTaskHasFPUContext = pdTRUE;

        portEXIT_CRITICAL();
    }

#endif // __MICROAPTIV_FP__ == 1

//-----------------------------------------------------------

void vPortTickInterruptHandler() iv IVT_TIMER_1 ics ICS_SOFT
{
    portISR_ENTRY();

    vPortIncrementTick();

    portISR_EXIT();
}
//-----------------------------------------------------------

void vPortYieldISR() iv IVT_CORE_SOFTWARE_0 ics ICS_OFF
{
    asm {
        // Have to do this, otherwise the stack will overflow.
        ADDIU SP, SP, 4

        // Make space on the stack.
        ADDIU SP, SP, -portCONTEXT_SIZE
        
        // Save R4 since it will be used here.
        SW  R4, 20(SP)

#if (__MICROAPTIV_FP__ == 1) && (configUSE_TASK_FPU_SUPPORT == 1)
        // Check if the task has FPU context. This is done through R4.
        LW  R4, Offset(_ulTaskHasFPUContext)(GP)
        BEQ R4, R0, yield_SkipFPU1
        NOP
        
        // The real value of R4 will have to be restored in this case.
        LW    R4, 20(SP)
        // Make space for the FPU registers on the stack.
        // It doesn't matter that this space was allocated
        // after the regular context space, since the size is same in the end.
        ADDIU SP, SP, -portFPU_CONTEXT_SIZE
        // Now save R4 to its correct place on the stack.
        SW    R4, 20(SP)

yield_SkipFPU1:
#endif

        // Save R5 and R6 since they will be used here.
        SW R5, 24(SP)
        SW R6, 28(SP)

        // Save the current status on the stack.
        MFC0 R4, _CP0_STATUS
        SW   R4, portSTATUS_STACK_LOCATION(SP)
        // Prepare to re-enable interrupts above the kernel priority.
        INS  R4, R0, 10, 7 // Clear IPL bits 0:6.
        INS  R4, R0, 18, 1 // Clear IPL bit 7. Would be an error if it was set.
    }
        R4 = R4 | (configMAX_SYSCALL_INTERRUPT_PRIORITY << 10);
    asm {
        INS  R4, R0, 1, 4  // Clear EXL, ERL and UM.
        
        // R5 is used as the stack pointer.
        ADD R5, R0, SP

        // Swap to the system stack.  This is not conditional on the nesting
        // count as this interrupt is always the lowest priority and therefore
        // the nesting is always 0.
        LW SP, Offset(_xISRStackTop)(GP)
        
        // Set the nesting count.
        ADDIU R6, R0, 1
        SW    R6, Offset(_uxInterruptNesting)(GP)
        
        // R6 holds the EPC value, this is saved with the rest of the context
        // after interrupts are enabled.
        MFC0 R6, _CP0_EPC
        
        // Re-enable interrupts above configMAX_SYSCALL_INTERRUPT_PRIORITY.
        MTC0 R4, _CP0_STATUS

        // Save the registers on the stack.
        SW R2,   12(R5)
        SW R3,   16(R5)
        // R4 was already saved.
        // R5 was already saved.
        // R6 was already saved.
        SW R7,   32(R5)
        SW R8,   36(R5)
        SW R9,   40(R5)
        SW R10,  44(R5)
        SW R11,  48(R5)
        SW R12,  52(R5)
        SW R13,  56(R5)
        SW R14,  60(R5)
        SW R15,  64(R5)
        SW R16,  68(R5)
        SW R17,  72(R5)
        SW R18,  76(R5)
        SW R19,  80(R5)
        SW R20,  84(R5)
        SW R21,  88(R5)
        SW R22,  92(R5)
        SW R23,  96(R5)
        SW R24, 100(R5)
        SW R25, 104(R5)
        SW R26, 108(R5)
        SW R27, 112(R5)
        SW R28, 116(R5)
        SW R30, 120(R5)
        SW R31, 124(R5)
        SW R6,  portEPC_STACK_LOCATION(R5) // CP0_EPC was saved to R6.
        /*
        // Save the DSP registers.
        MFHI  R4, AC1
        SW    R4, 132(R5)
        MFLO  R4, AC1
        SW    R4, 128(R5)

        MFHI  R4, AC2
        SW    R4, 140(R5)
        MFLO  R4, AC2
        SW    R4, 136(R5)

        MFHI  R4, AC3
        SW    R4, 148(R5)
        MFLO  R4, AC3
        SW    R4, 144(R5)

        RDDSP R4
        SW    R4, 152(R5)

        MFHI  R4, AC0
        SW    R4, 8(R5)
        MFLO  R4, AC0
        SW    R4, 4(R5)
        */

#if (__MICROAPTIV_FP__ == 1) && (configUSE_TASK_FPU_SUPPORT == 1)
        // Check if the task is using FPU context.
        LW  R4, Offset(_ulTaskHasFPUContext)(GP)
        BEQ R4, R0, yield_SkipFPU2
        // Save the indicator in the meantime. This is always executed.
        SW  R4, portTASK_HAS_FPU_STACK_LOCATION(R5)
        
        // Check if R5 + 172 (start of FPU regs space) is aligned to 8 bytes.
        ANDI R4, R5, 4
        BNE  R4, R0, yield_TestAlign1
        NOP
        
        // Align R5 + 172 to 8 bytes. This is ok since there are 4 bytes
        // available above portFPCSR_STACK_LOCATION_ABSOLUTE.
        ADDIU R5, R5, -4

yield_TestAlign1:
        // Save the FPU registers above the normal context.
        SDC1 S0,  172(R5)
        SDC1 S1,  180(R5)
        SDC1 S2,  188(R5)
        SDC1 S3,  196(R5)
        SDC1 S4,  204(R5)
        SDC1 S5,  212(R5)
        SDC1 S6,  220(R5)
        SDC1 S7,  228(R5)
        SDC1 S8,  236(R5)
        SDC1 S9,  244(R5)
        SDC1 S10, 252(R5)
        SDC1 S11, 260(R5)
        SDC1 S12, 268(R5)
        SDC1 S13, 276(R5)
        SDC1 S14, 284(R5)
        SDC1 S15, 292(R5)
        SDC1 S16, 300(R5)
        SDC1 S17, 308(R5)
        SDC1 S18, 316(R5)
        SDC1 S19, 324(R5)
        SDC1 S20, 332(R5)
        SDC1 S21, 340(R5)
        SDC1 S22, 348(R5)
        SDC1 S23, 356(R5)
        SDC1 S24, 364(R5)
        SDC1 S25, 372(R5)
        SDC1 S26, 380(R5)
        SDC1 S27, 388(R5)
        SDC1 S28, 396(R5)
        SDC1 S29, 404(R5)
        SDC1 S30, 412(R5)
        SDC1 S31, 420(R5)
        
        // Check if R5 + 172 was aligned to 8 bytes before storing FPU regs.
        // The value in R4 still indicates this.
        BNE R4, R0, yield_TestAlign2
        NOP
        
        // Revert R5 to the value it had.
        ADDIU R5, R5, 4
        
yield_TestAlign2:
        // Save the FPU status register.
        CFC1 R4, S31
        SW   R4, portFPCSR_STACK_LOCATION_ABSOLUTE(R5)

yield_SkipFPU2:
#endif

        // Save the stack pointer to the TCB.
        LW R4, Offset(_pxCurrentTCB)(GP)
        SW R5, (R4)

        // Set the interrupt mask to the max priority that can use the API.
        DI
        EHB
        MFC0 R7, _CP0_STATUS
        INS  R7, R0, 10, 7
        INS  R7, R0, 18, 1
    }
        R6 = R7 | ((configMAX_SYSCALL_INTERRUPT_PRIORITY << 10) | 1);
    asm {
        // Re-enable interrupts above configMAX_SYSCALL_INTERRUPT_PRIORITY.
        MTC0 R6, _CP0_STATUS
        EHB

        // Clear the software interrupt in the core.
        MFC0 R6, _CP0_CAUSE
        INS  R6, R0, 8, 1
        MTC0 R6, _CP0_CAUSE
        EHB
    }

        // Clear the interrupt in the interrupt controller.
        IFS0CLRbits.CS0IF = 0x01;

    asm {
        // Perform the context switch.
        JAL _vTaskSwitchContext
        NOP
        
        // Clear the interrupt mask again. The saved status value is in R7.
        MTC0 R7, _CP0_STATUS
        EHB
        
        // Restore the stack pointer from the TCB.
        LW R4, Offset(_pxCurrentTCB)(GP)
        LW R5, (R4)

#if (__MICROAPTIV_FP__ == 1) && (configUSE_TASK_FPU_SUPPORT == 1)
        // Test if the FPU context needs restoring.
        LW  R4, portTASK_HAS_FPU_STACK_LOCATION(R5)
        BEQ R4, R0, yield_SkipFPU3
        // Restore the indicator in the meantime. This is always executed.
        SW  R4, Offset(_ulTaskHasFPUContext)(GP)
        
        // Restore the FPU status register.
        LW   R4, portFPCSR_STACK_LOCATION_ABSOLUTE(R5)
        CTC1 R4, S31

        // Check if R5 + 172 (start of FPU regs space) is aligned to 8 bytes.
        ANDI R4, R5, 4
        BNE  R4, R0, yield_TestAlign3
        NOP

        // Align R5 + 172 to 8 bytes. This is how the GPU registers are saved
        // when entering vPortYieldISR.
        ADDIU R5, R5, -4

yield_TestAlign3:
        // Restore the FPU registers.
        LDC1 S31, 420(R5)
        LDC1 S30, 412(R5)
        LDC1 S29, 404(R5)
        LDC1 S28, 396(R5)
        LDC1 S27, 388(R5)
        LDC1 S26, 380(R5)
        LDC1 S25, 372(R5)
        LDC1 S24, 364(R5)
        LDC1 S23, 356(R5)
        LDC1 S22, 348(R5)
        LDC1 S21, 340(R5)
        LDC1 S20, 332(R5)
        LDC1 S19, 324(R5)
        LDC1 S18, 316(R5)
        LDC1 S17, 308(R5)
        LDC1 S16, 300(R5)
        LDC1 S15, 292(R5)
        LDC1 S14, 284(R5)
        LDC1 S13, 276(R5)
        LDC1 S12, 268(R5)
        LDC1 S11, 260(R5)
        LDC1 S10, 252(R5)
        LDC1 S9,  244(R5)
        LDC1 S8,  236(R5)
        LDC1 S7,  228(R5)
        LDC1 S6,  220(R5)
        LDC1 S5,  212(R5)
        LDC1 S4,  204(R5)
        LDC1 S3,  196(R5)
        LDC1 S2,  188(R5)
        LDC1 S1,  180(R5)
        LDC1 S0,  172(R5)

        // Check if R5 + 172 was aligned to 8 bytes before loading FPU regs.
        // The value in R4 still indicates this.
        BNE R4, R0, yield_TestAlign4
        NOP

        // Revert R5 to the value it had.
        ADDIU R5, R5, 4

yield_TestAlign4:
yield_SkipFPU3:
#endif

        // Restore the rest of the context.
        /*
        // Restore the DSP registers.
        LW    R4, 132(R5)
        MTHI  R4, AC1
        LW    R4, 128(R5)
        MTLO  R4, AC1

        LW    R4, 140(R5)
        MTHI  R4, AC2
        LW    R4, 136(R5)
        MTLO  R4, AC2

        LW    R4, 148(R5)
        MTHI  R4, AC3
        LW    R4, 144(R5)
        MTLO  R4, AC3

        LW    R4, 152(R5)
        WRDSP R4

        LW    R4, 8(R5)
        MTHI  R4, AC0
        LW    R4, 4(R5)
        MTLO  R4, AC0
        */
        // Restore the rest of the registers.
        LW R31, 124(R5)
        LW R30, 120(R5)
        LW R28, 116(R5)
        LW R27, 112(R5)
        LW R26, 108(R5)
        LW R25, 104(R5)
        LW R24, 100(R5)
        LW R23,  96(R5)
        LW R22,  92(R5)
        LW R21,  88(R5)
        LW R20,  84(R5)
        LW R19,  80(R5)
        LW R18,  76(R5)
        LW R17,  72(R5)
        LW R16,  68(R5)
        LW R15,  64(R5)
        LW R14,  60(R5)
        LW R13,  56(R5)
        LW R12,  52(R5)
        LW R11,  48(R5)
        LW R10,  44(R5)
        LW R9,   40(R5)
        LW R8,   36(R5)
        LW R7,   32(R5)
        // R6 is restored later.
        // R5 is restored later.
        // R4 is restored later.
        LW R3,   16(R5)
        LW R2,   12(R5)
        
        // Protect access to the registers.
        DI
        EHB
        
        // Set nesting back to zero.  As the lowest priority interrupt this
        // interrupt cannot have nested.
        SW R0, Offset(_uxInterruptNesting)(GP)
        
        // Switch back to use the real stack pointer.
        ADD SP, R0, R5
        
        // Restore the real R5 value.
        LW R5, 24(SP)
        
        // Get the status and epc values.
        LW   R4, portSTATUS_STACK_LOCATION(SP)
        LW   R6, portEPC_STACK_LOCATION(SP)
        // Restore status and epc values.
        MTC0 R4, _CP0_STATUS
        MTC0 R6, _CP0_EPC
        // Restore R4 and R6.
        LW   R4, 20(SP)
        LW   R6, 28(SP)

        // Remove the stack frame.
        ADDIU SP, SP, portCONTEXT_SIZE
        
#if (__MICROAPTIV_FP__ == 1) && (configUSE_TASK_FPU_SUPPORT == 1)
        // Make temporary space for saving R4 since it will be used here.
        ADDIU SP, SP, -4
        SW    R4, 0(SP)
        // Check if the task has FPU context.
        LW  R4, Offset(_ulTaskHasFPUContext)(GP)
        BEQ R4, R0, yield_SkipFPU4
        LW  R4, 0(SP) // This will always execute regardless of the branch.

        // Remove the space for the FPU registers on the stack.
        // It doesn't matter that this space is removed
        // before the temporary space for R4.
        ADDIU SP, SP, portFPU_CONTEXT_SIZE

yield_SkipFPU4:
        // Remove the temporary space for R4.
        ADDIU SP, SP, 4
#endif

        EHB
        ERET
        NOP
    }
}
//-----------------------------------------------------------