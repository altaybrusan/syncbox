// button_task.c

// This file contains the button task which polls several buttons,
// and sends data about the one pressed to the TFT draw task.

// Includes

#include "main.h"

// Memory Declarations

// Buttons
static sbit BTN0 at PORTF.B4;
static sbit BTN1 at PORTF.B5;
static sbit BTN2 at PORTF.B12;
static sbit BTN3 at PORTF.B13;

static TDisplayMessage msgBuffer; // Buffer for messages

// Public Function Definitions

// Polls several buttons
// and sends indication about the one pressed to the display task.
void buttonTask(void *pvParameters)
{
    uint8_t oldState0 = 0;
    uint8_t oldState1 = 0;
    uint8_t oldState2 = 0;
    uint8_t oldState3 = 0;
    uint8_t button0 = 0;
    uint8_t button1 = 0;
    uint8_t button2 = 0;
    uint8_t button3 = 0;

    // Configure button pins as input.
    TRISF.B4 = 1;
    TRISF.B5 = 1;
    TRISF.B12 = 1;
    TRISF.B13 = 1;

    msgBuffer.msgType = MSG_BUTTON;
    msgBuffer.msgData[1] = 0;
    
    // Constantly check for buttons.
    while (1)
    {
        // Check button 0.
        if (BTN0)
            oldState0 = 1;
        if (oldState0 && !BTN0)
        {
            button0 = 1;
            oldState0 = 0;
        }

        // Check button 1.
        if (BTN1)
            oldState1 = 1;
        if (oldState1 && !BTN1)
        {
            button1 = 1;
            oldState1 = 0;
        }

        // Check button 2.
        if (BTN2)
            oldState2 = 1;
        if (oldState2 && !BTN2)
        {
            button2 = 1;
            oldState2 = 0;
        }

        // Check button 3.
        if (BTN3)
            oldState3 = 1;
        if (oldState3 && !BTN3)
        {
            button3 = 1;
            oldState3 = 0;
        }

        // If a button is pressed, send the appropriate message.
        if (button0)
        {
            msgBuffer.msgData[0] = 0;
            xQueueSend(displayQueueHandle, &msgBuffer, 0xFFFFFFFFU);
            button0 = 0;
        }
        if (button1)
        {
            msgBuffer.msgData[0] = 1;
            xQueueSend(displayQueueHandle, &msgBuffer, 0xFFFFFFFFU);
            button1 = 0;
        }
        if (button2)
        {
            msgBuffer.msgData[0] = 2;
            xQueueSend(displayQueueHandle, &msgBuffer, 0xFFFFFFFFU);
            button2 = 0;
        }
        if (button3)
        {
            msgBuffer.msgData[0] = 3;
            xQueueSend(displayQueueHandle, &msgBuffer, 0xFFFFFFFFU);
            button3 = 0;
        }
    }
}