// ADC_task.c

// This file contains the ADC task, which reads the analog input.

// Includes

#include "main.h"

// Memory Declarations

static TDisplayMessage msgBuffer; // Buffer for messages

// Public Function Definitions

// Reads the analog input on the board
// and sends the converted value to the display task.
void adcReadTask(void *pvParameters)
{
    uint16_t adcSample;
    uint16_t adcSampleOld;

    // Initialize ADC.
    ADC1_Init_Advanced(_ADC_REF_AVDD_AVSS);
    vTaskDelay(pdMS_TO_TICKS(100));

    adcSampleOld = 0xFFFFU;
    msgBuffer.msgType = MSG_ADC_SAMPLE;
    
    // Periodically read ADC input and send it via the queue.
    while (1)
    {
        // Get ADC value from the corresponding channel.
        adcSample = ADC1_Get_Sample(1) >> 2;

        if (adcSample != adcSampleOld)
        {
            // Send measured ADC data to the display queue.
            msgBuffer.msgData[0] = adcSample & 0xFF;
            msgBuffer.msgData[1] = (adcSample >> 8) & 0xFF;
            xQueueSend(displayQueueHandle, &msgBuffer, 0xFFFFFFFFU);

            adcSampleOld = adcSample;
        }
        
        // Some delay.
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}