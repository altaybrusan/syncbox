/*
 * Project name:
     FreeRTOS Blank
 * Copyright:
     (c) Mikroelektronika, 2017.
 * Revision History:
     20170718:
       - Initial release;
 * Description:
     This is a blank project which includes all the files
     required for building an application that uses FreeRTOS,
     and can be used as a template for making your own FreeRTOS applications.
 * Test configuration:
     MCU:             P32MZ2048EFH144
                      http://ww1.microchip.com/downloads/en/DeviceDoc/60001320D.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 200.000MHz
     Ext. Modules:    None
     SW:              mikroC PRO for PIC32
                      http://www.mikroe.com/mikroc/pic32/
 */

// Includes

#include "main.h"

// Public Function Definitions

// Task 1 - An example task.
void task1(void *pvParameters)
{
    // Your code goes here...
    
    while (1)
    {
        // ...
    }
}

// Main function, which creates the tasks and starts the scheduler.
void main()
{
    // Disable shadow register context saving for interrupt level 1.
    PRISS &= 0xFFFFFF0F;

    // Create task 1.
    xTaskCreate(
        (TaskFunction_t)task1,
        "Task 1",
        configMINIMAL_STACK_SIZE,
        NULL,
        1,
        NULL
    );

    // Start the RTOS scheduler.
    vTaskStartScheduler();
    
    // Will never reach here.
    while (1);
}