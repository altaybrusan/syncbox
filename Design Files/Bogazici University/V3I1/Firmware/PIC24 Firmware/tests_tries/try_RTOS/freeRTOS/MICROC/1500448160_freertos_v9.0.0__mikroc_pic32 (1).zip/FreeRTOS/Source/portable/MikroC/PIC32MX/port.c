/*
    FreeRTOS V9.0.1 - Copyright (C) 2017 Real Time Engineers Ltd.
    All rights reserved

    VISIT http://www.FreeRTOS.org TO ENSURE YOU ARE USING THE LATEST VERSION.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation >>>> AND MODIFIED BY <<<< the FreeRTOS exception.

    ***************************************************************************
    >>!   NOTE: The modification to the GPL is included to allow you to     !<<
    >>!   distribute a combined work that includes FreeRTOS without being   !<<
    >>!   obliged to provide the source code for proprietary components     !<<
    >>!   outside of the FreeRTOS kernel.                                   !<<
    ***************************************************************************

    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT ANY
    WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
    FOR A PARTICULAR PURPOSE.  Full license text is available on the following
    link: http://www.freertos.org/a00114.html

    ***************************************************************************
     *                                                                       *
     *    FreeRTOS provides completely free yet professionally developed,    *
     *    robust, strictly quality controlled, supported, and cross          *
     *    platform software that is more than just the market leader, it     *
     *    is the industry's de facto standard.                               *
     *                                                                       *
     *    Help yourself get started quickly while simultaneously helping     *
     *    to support the FreeRTOS project by purchasing a FreeRTOS           *
     *    tutorial book, reference manual, or both:                          *
     *    http://www.FreeRTOS.org/Documentation                              *
     *                                                                       *
    ***************************************************************************

    http://www.FreeRTOS.org/FAQHelp.html - Having a problem?  Start by reading
    the FAQ page "My application does not run, what could be wrong?".  Have you
    defined configASSERT()?

    http://www.FreeRTOS.org/support - In return for receiving this top quality
    embedded software for free we request you assist our global community by
    participating in the support forum.

    http://www.FreeRTOS.org/training - Investing in training allows your team to
    be as productive as possible as early as possible.  Now you can receive
    FreeRTOS training directly from Richard Barry, CEO of Real Time Engineers
    Ltd, and the world's leading authority on the world's leading RTOS.

    http://www.FreeRTOS.org/plus - A selection of FreeRTOS ecosystem products,
    including FreeRTOS+Trace - an indispensable productivity tool, a DOS
    compatible FAT file system, and our tiny thread aware UDP/IP stack.

    http://www.FreeRTOS.org/labs - Where new FreeRTOS products go to incubate.
    Come and try FreeRTOS+TCP, our new open source TCP/IP stack for FreeRTOS.

    http://www.OpenRTOS.com - Real Time Engineers ltd. license FreeRTOS to High
    Integrity Systems ltd. to sell under the OpenRTOS brand.  Low cost OpenRTOS
    licenses offer ticketed support, indemnification and commercial middleware.

    http://www.SafeRTOS.com - High Integrity Systems also provide a safety
    engineered and independently SIL3 certified version for use in safety and
    mission critical applications that require provable dependability.

    1 tab == 4 spaces!
*/

//-----------------------------------------------------------
// Implementation of functions defined in portable.h for the PIC32MX port.
//-----------------------------------------------------------

// Scheduler include files.
#include "FreeRTOS.h"
#include "task.h"

// Hardware specifics.
#define portTIMER_PRESCALE       8
#define portPRESCALE_BITS        1

// Bits within various registers.
#define portIE_BIT               (0x00000001)
#define portEXL_BIT              (0x00000002)

// Bits within the CAUSE register.
#define portCORE_SW_0            (0x00000100)
#define portCORE_SW_1            (0x00000200)

// The EXL bit is set to ensure interrupts do not occur
// while the context of the first task is being restored.
#define portINITIAL_SR           (portIE_BIT | portEXL_BIT)

/*
By default port.c generates its tick interrupt from TIMER1.  The user can
override this behaviour by:
    1: Providing their own implementation of vApplicationSetupTickTimerInterrupt(),
       which is the function that configures the timer.  The function is defined
       as a weak symbol in this file so if the same function name is used in the
       application code then the version in the application code will be linked
       into the application in preference to the version defined in this file.
    2: Define configTICK_INTERRUPT_VECTOR to the vector number of the timer used
       to generate the tick interrupt.  For example, when timer 1 is used then
       configTICK_INTERRUPT_VECTOR is set to _TIMER_1_VECTOR.
       configTICK_INTERRUPT_VECTOR should be defined in FreeRTOSConfig.h.
    3: Define configCLEAR_TICK_TIMER_INTERRUPT() to clear the interrupt in the
       timer used to generate the tick interrupt.  For example, when timer 1 is
       used configCLEAR_TICK_TIMER_INTERRUPT() is defined to
       IFS0CLRbits.T1IF = 0x1.
*/
#ifndef configTICK_INTERRUPT_VECTOR
    #define configTICK_INTERRUPT_VECTOR _TIMER_1_VECTOR
    #define configCLEAR_TICK_TIMER_INTERRUPT() IFS0CLRbits.T1IF = 0x1
#else
    #ifndef configCLEAR_TICK_TIMER_INTERRUPT
        #error If configTICK_INTERRUPT_VECTOR is defined in application code then configCLEAR_TICK_TIMER_INTERRUPT must also be defined in application code.
    #endif
#endif

// Let the user override the pre-loading of the initial RA
// with the address of prvTaskExitError()
// in case it messes up unwinding of the stack in the debugger
// - in which case configTASK_RETURN_ADDRESS can be defined as 0 (NULL).
#ifdef configTASK_RETURN_ADDRESS
    #define portTASK_RETURN_ADDRESS configTASK_RETURN_ADDRESS
#else
    #define portTASK_RETURN_ADDRESS prvTaskExitError
#endif

// Set configCHECK_FOR_STACK_OVERFLOW to 3 to add ISR stack checking to task
// stack checking.  A problem in the ISR stack will trigger an assert, not call
// the stack overflow hook function (because the stack overflow hook is specific
// to a task stack, not the ISR stack).
#if (configCHECK_FOR_STACK_OVERFLOW > 2)

    // Don't use 0xa5 as the stack fill bytes as that is used by the kernel for
    // the task stacks, and so will legitimately appear in many positions within
    // the ISR stack.
    #define portISR_STACK_FILL_BYTE        0xEE

    static const uint8_t ucExpectedStackBytes[] =
    {
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE,
        portISR_STACK_FILL_BYTE, portISR_STACK_FILL_BYTE
    };

    #define portCHECK_ISR_STACK()                                              \
        configASSERT((memcmp((void *)xISRStack, (void *) ucExpectedStackBytes, \
        sizeof(ucExpectedStackBytes)) == 0))
#else
    // Define the function away.
    #define portCHECK_ISR_STACK()
#endif // configCHECK_FOR_STACK_OVERFLOW > 2

//-----------------------------------------------------------

#define portCONTEXT_SIZE          132
#define portSTATUS_STACK_LOCATION 128
#define portEPC_STACK_LOCATION    124

//-----------------------------------------------------------

// The tick interrupt handler that increases the tick count
// and checks if context switching is required.
// The interrupt priority is set in vApplicationSetupTickTimerInterrupt().
extern void vPortTickInterruptHandler();

// The software interrupt handler that performs the yield.
// The interrupt priority is set in xPortStartScheduler().
void vPortYieldISR();

// Used to catch tasks that attempt to return from their implementing function.
static void prvTaskExitError();

//-----------------------------------------------------------

// From tasks.c.
extern void *pxCurrentTCB;

// Task function pointer for pragma indfuncall.
void (*vTaskFunction)(void*);

// Records the interrupt nesting depth.
volatile UBaseType_t uxInterruptNesting = 0x00;

// Stores the task stack pointer when a switch is made to use the system stack.
UBaseType_t uxSavedTaskStackPointer = 0;

// The stack used by interrupt service routines that cause a context switch.
StackType_t xISRStack[configISR_STACK_SIZE] = { 0 };

// The top of stack value ensures there is enough space to store 6 registers on
// the callers stack, as some functions seem to want to do this.
const StackType_t * const xISRStackTop =
    &(xISRStack[(configISR_STACK_SIZE & ~portBYTE_ALIGNMENT_MASK) - 8]);

//-----------------------------------------------------------

// See header file for description.
StackType_t *pxPortInitialiseStack(
    StackType_t *pxTopOfStack, TaskFunction_t pxCode, void *pvParameters)
{
    *pxTopOfStack = (StackType_t) CP0_GET(CP0_CAUSE);

    // CP0_STATUS
    pxTopOfStack--;
    *pxTopOfStack = (StackType_t) portINITIAL_SR;

    // CP0_EPC
    pxTopOfStack--;
    *pxTopOfStack = (StackType_t) pxCode;

    // R31 (return address)
    pxTopOfStack--;
    *pxTopOfStack = (StackType_t) portTASK_RETURN_ADDRESS;

    // R25 - Parameter to pass in.
    pxTopOfStack -= 5;
    *pxTopOfStack = (StackType_t) pvParameters;
    
    // Space for registers.
    pxTopOfStack -= 25;

    return pxTopOfStack;
}
//-----------------------------------------------------------

#pragma funcall pxPortInitialiseStack prvTaskExitError

static void prvTaskExitError()
{
    // A function that implements a task must not exit or attempt to return to
    // its caller as there is nothing to return to.  If a task wants to exit it
    // should instead call vTaskDelete(NULL).

    // Artificially force an assert() to be triggered if configASSERT() is
    // defined, then stop here so application writers can catch the error.
    configASSERT(uxSavedTaskStackPointer == 0UL);
    portDISABLE_INTERRUPTS();
    while (1);
}
//-----------------------------------------------------------

// Setup a timer for a regular tick.  This function uses peripheral timer 1.
// The function is declared weak so an application writer can use a different
// timer by redefining this implementation.  If a different timer is used then
// configTICK_INTERRUPT_VECTOR must also be defined in FreeRTOSConfig.h to
// ensure the RTOS provided tick interrupt handler is installed on the correct
// vector number.  When Timer 1 is used the vector number is defined as
// _TIMER_1_VECTOR.
void vApplicationSetupTickTimerInterrupt()
{
    const uint32_t ulCompareMatch =
        ((configPERIPHERAL_CLOCK_HZ / portTIMER_PRESCALE)
        / configTICK_RATE_HZ ) - 1UL;

    T1CON = 0x0000;
    T1CONbits.TCKPS = portPRESCALE_BITS;
    PR1 = ulCompareMatch;
    IPC1bits.T1IP = configKERNEL_INTERRUPT_PRIORITY;

    // Clear the interrupt as a starting condition.
    IFS0bits.T1IF = 0;

    // Enable the interrupt.
    IEC0bits.T1IE = 1;

    // Start the timer.
    T1CONbits.TON = 1;
}
//-----------------------------------------------------------

void vPortStartFirstTask()
{
    // Simply restore the context of the highest priority task that has been
    // created so far.
    asm {
        // Get the top of stack of the first task to execute.
        LW SP, Offset(_pxCurrentTCB)(GP)
        LW SP, (SP)
        
        // Restore only the necessary registers.
        LW R25, 100(SP) // Task argument.
        LW R31, 120(SP) // Task return address.
        LW R4,  portEPC_STACK_LOCATION(SP) // CP0_EPC
        LW R5,  portSTATUS_STACK_LOCATION(SP) // CP0_STATUS

        // Update the stack pointer.
        ADDIU SP, SP, portCONTEXT_SIZE
        
        // Set CP0_STATUS and CP0_EPC values.
        MTC0 R5, _CP0_STATUS
        MTC0 R4, _CP0_EPC
        
        // Simulate a return from exception.
        ERET
        NOP
    }
}
//-----------------------------------------------------------

void vPortEndScheduler()
{
    // Not implemented in ports where there is nothing to return to.
    // Artificially force an assert.
    configASSERT(uxInterruptNesting == 1000UL);
}
//-----------------------------------------------------------

BaseType_t xPortStartScheduler()
{
    #if (configCHECK_FOR_STACK_OVERFLOW > 2)
    {
        // Fill the ISR stack to make it easy to assess how much is being used.
        memset((void *)xISRStack, portISR_STACK_FILL_BYTE, sizeof(xISRStack));
    }
    #endif // configCHECK_FOR_STACK_OVERFLOW > 2

    // Clear the software interrupt flag.
    IFS0CLRbits.CS0IF = 0x1;

    // Set software timer priority.
    IPC0CLRbits.CS0IP = 0x7;
    IPC0SETbits.CS0IP = configKERNEL_INTERRUPT_PRIORITY;

    // Enable software interrupt.
    IEC0CLRbits.CS0IE = 0x1;
    IEC0SETbits.CS0IE = 0x1;

    // Setup the timer to generate the tick.
    // Interrupts will have been disabled by the time we get here.
    vApplicationSetupTickTimerInterrupt();

    // Kick off the highest priority task that has been created so far.
    // Its stack location is loaded into uxSavedTaskStackPointer.
    uxSavedTaskStackPointer = *(UBaseType_t *)pxCurrentTCB;
    vPortStartFirstTask();

    // Should never get here as the tasks will now be executing!
    // Call the task exit error function just in case.
    prvTaskExitError();

    // Should not get here!
    return pdFALSE;
}

// Pragma to enable linking of functions that are not explicitly called,
// i.e. tasks.
#pragma indfuncall xPortStartScheduler vTaskFunction

//-----------------------------------------------------------

void vPortIncrementTick()
{
    UBaseType_t uxSavedStatus;

    uxSavedStatus = uxPortSetInterruptMaskFromISR();
    {
        if (xTaskIncrementTick() != pdFALSE)
        {
            // Pend a context switch.
            CP0_SET(CP0_CAUSE, CP0_GET(CP0_CAUSE) | portCORE_SW_0);
        }
    }
    vPortClearInterruptMaskFromISR(uxSavedStatus);

    // Look for the ISR stack getting near or past its limit.
    portCHECK_ISR_STACK();

    // Clear timer interrupt.
    configCLEAR_TICK_TIMER_INTERRUPT();
}
//-----------------------------------------------------------

UBaseType_t uxPortSetInterruptMaskFromISR()
{
    UBaseType_t uxSavedStatusRegister;

    DisableInterrupts();
    uxSavedStatusRegister = CP0_GET(CP0_STATUS) | 0x01;
    // This clears the IPL bits, then sets them to
    // configMAX_SYSCALL_INTERRUPT_PRIORITY.  This function should not be called
    // from an interrupt that has a priority above
    // configMAX_SYSCALL_INTERRUPT_PRIORITY so, when used correctly, the action
    // can only result in the IPL being unchanged or raised, and therefore never
    // lowered.
    CP0_SET(CP0_STATUS, (uxSavedStatusRegister & (~portALL_IPL_BITS)) |
        (configMAX_SYSCALL_INTERRUPT_PRIORITY << portIPL_SHIFT));

    return uxSavedStatusRegister;
}
//-----------------------------------------------------------

void vPortClearInterruptMaskFromISR(UBaseType_t uxSavedStatusRegister)
{
    CP0_SET(CP0_STATUS, uxSavedStatusRegister);
}
//-----------------------------------------------------------

void vPortTickInterruptHandler() iv IVT_TIMER_1 ics ICS_SOFT
{
    portISR_ENTRY();

    vPortIncrementTick();

    portISR_EXIT();
}
//-----------------------------------------------------------

void vPortYieldISR() iv IVT_CORE_SOFTWARE_0 ics ICS_OFF
{
    asm {
        // Have to do this, otherwise the stack will overflow.
        ADDIU SP, SP, 4
    
        // Make space on the stack.
        ADDIU SP, SP, -portCONTEXT_SIZE
        
        // Save R4, R5, and R6 since they will be used later.
        SW R4, 16(SP)
        SW R5, 20(SP)
        SW R6, 24(SP)

        // Save the current status on the stack.
        MFC0 R4, _CP0_STATUS
        SW   R4, portSTATUS_STACK_LOCATION(SP)
        // Prepare to re-enable interrupts above the kernel priority.
        INS  R4, R0, 10, 6
    }
        R4 = R4 | (configMAX_SYSCALL_INTERRUPT_PRIORITY << 10);
    asm {
        INS  R4, R0, 1, 4
        
        // R5 is used as the stack pointer.
        ADD R5, R0, SP
        
        // Swap to the system stack.  This is not conditional on the nesting
        // count as this interrupt is always the lowest priority and therefore
        // the nesting is always 0.
        LW SP, Offset(_xISRStackTop)(GP)
        
        // Set the nesting count.
        ADDIU R6, R0, 1
        SW    R6, Offset(_uxInterruptNesting)(GP)
        
        // R6 holds the EPC value, this is saved with the rest of the context
        // after interrupts are enabled.
        MFC0 R6, _CP0_EPC
        
        // Re-enable interrupts above configMAX_SYSCALL_INTERRUPT_PRIORITY.
        MTC0 R4, _CP0_STATUS

        // Save the registers on the stack.
        SW R2,    8(R5)
        SW R3,   12(R5)
        // R4 was already saved.
        // R5 was already saved.
        // R6 was already saved.
        SW R7,   28(R5)
        SW R8,   32(R5)
        SW R9,   36(R5)
        SW R10,  40(R5)
        SW R11,  44(R5)
        SW R12,  48(R5)
        SW R13,  52(R5)
        SW R14,  56(R5)
        SW R15,  60(R5)
        SW R16,  64(R5)
        SW R17,  68(R5)
        SW R18,  72(R5)
        SW R19,  76(R5)
        SW R20,  80(R5)
        SW R21,  84(R5)
        SW R22,  88(R5)
        SW R23,  92(R5)
        SW R24,  96(R5)
        SW R25, 100(R5)
        SW R26, 104(R5)
        SW R27, 108(R5)
        SW R28, 112(R5)
        SW R30, 116(R5)
        SW R31, 120(R5)
        SW R6,  portEPC_STACK_LOCATION(R5) // CP0_EPC was saved to R6.
        
        // Save HI and LO.
        MFHI R4
        SW   R4, 4(R5)
        MFLO R4
        SW   R4, 0(R5)
        
        // Save the stack pointer to the TCB.
        LW R4, Offset(_pxCurrentTCB)(GP)
        SW R5, (R4)

        // Set the interrupt mask to the max priority that can use the API.
        DI
        EHB
        MFC0 R7, _CP0_STATUS
        INS  R7, R0, 10, 6
    }
        R6 = R7 | ((configMAX_SYSCALL_INTERRUPT_PRIORITY << 10) | 1);
    asm {
        // Re-enable interrupts above configMAX_SYSCALL_INTERRUPT_PRIORITY.
        MTC0 R6, _CP0_STATUS
        EHB

        // Clear the software interrupt in the core.
        MFC0 R6, _CP0_CAUSE
        INS  R6, R0, 8, 1
        MTC0 R6, _CP0_CAUSE
        EHB
    }
    
        // Clear the interrupt in the interrupt controller.
        IFS0CLRbits.CS0IF = 0x01;
        
    asm {
        // Perform the context switch.
        JAL _vTaskSwitchContext
        NOP
        
        // Clear the interrupt mask again. The saved status value is in R7.
        MTC0 R7, _CP0_STATUS
        EHB
        
        // Restore the stack pointer from the TCB.
        LW R4, Offset(_pxCurrentTCB)(GP)
        LW R5, (R4)
        
        // Restore the context.
        
        // Restore HI and LO.
        LW   R4, 4(R5)
        MTHI R4
        LW   R4, 0(R5)
        MTLO R4
        
        // Restore the rest of the registers.
        LW R31, 120(R5)
        LW R30, 116(R5)
        LW R28, 112(R5)
        LW R27, 108(R5)
        LW R26, 104(R5)
        LW R25, 100(R5)
        LW R24,  96(R5)
        LW R23,  92(R5)
        LW R22,  88(R5)
        LW R21,  84(R5)
        LW R20,  80(R5)
        LW R19,  76(R5)
        LW R18,  72(R5)
        LW R17,  68(R5)
        LW R16,  64(R5)
        LW R15,  60(R5)
        LW R14,  56(R5)
        LW R13,  52(R5)
        LW R12,  48(R5)
        LW R11,  44(R5)
        LW R10,  40(R5)
        LW R9,   36(R5)
        LW R8,   32(R5)
        LW R7,   28(R5)
        // R6 is restored later.
        // R5 is restored later.
        // R4 is restored later.
        LW R3,   12(R5)
        LW R2,    8(R5)
        
        // Protect access to the registers.
        DI
        EHB
        
        // Set nesting back to zero.  As the lowest priority interrupt this
        // interrupt cannot have nested.
        SW R0, Offset(_uxInterruptNesting)(GP)
        
        // Switch back to use the real stack pointer.
        ADD SP, R0, R5
        
        // Restore the real R5 value.
        LW R5, 20(SP)
        
        // Get the status and epc values.
        LW   R4, portSTATUS_STACK_LOCATION(SP)
        LW   R6, portEPC_STACK_LOCATION(SP)
        // Restore status and epc values.
        MTC0 R4, _CP0_STATUS
        MTC0 R6, _CP0_EPC
        // Restore R4 and R6.
        LW   R4, 16(SP)
        LW   R6, 24(SP)

        // Remove the stack frame.
        ADDIU SP, SP, portCONTEXT_SIZE
        
        EHB
        ERET
        NOP
    }
}
//-----------------------------------------------------------