// main.h

// Includes the necessary FreeRTOS headers, and declares all task functions.

#ifndef _main_h_
#define _main_h_

// Includes

#include <stdint.h>
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "projdefs.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

// Preprocessor Constants

// Message constants
#define MSG_DATA_LENGTH  2   // Message data length
#define MSG_QUEUE_LENGTH 10  // Message queue length

// Typedefs

//Types of messages that can be sent to the TFT display task.
typedef enum
{
    MSG_BUTTON,
    MSG_ADC_SAMPLE,
    MSG_ERROR
}
TDisplayMsgTypes;

// Structure of a message that is sent to the TFT display task.
typedef struct
{
    TDisplayMsgTypes msgType;                  // Message type
    uint8_t          msgData[MSG_DATA_LENGTH]; // Message data
}
TDisplayMessage;

// Queue handles
extern QueueHandle_t     displayQueueHandle; // TFT draw queue handle
extern SemaphoreHandle_t ledBlinkSemHandle;  // LED blink queue handle

// Public Function Prototypes

// Initializes structures and other tasks.
// Should be the only task initialized in main.
void initTask(void *pvParameters);

// Displays user input on TFT and LED.
void displayTask(void *pvParameters);

// Reads the analog input on the board
// and sends the converted value to the display task.
void adcReadTask(void *pvParameters);

// Returns ADC value of the LED blink task. This is a thread-safe function.
uint16_t ledBlinkGetAdcValue();

// Sets ADC value of the LED blink task. This is a thread-safe function.
void ledBlinkSetAdcValue(uint16_t newAdcValue);

// Returns blink delay of the LED blink task. This is a thread-safe function.
uint16_t ledBlinkGetBlinkDelay();

// Sets blink delay of the LED blink task. This is a thread-safe function.
void ledBlinkSetBlinkDelay(uint16_t newBlinkDelay);

// Receives data from the display task and blinks LEDs accordingly.
void ledBlinkTask(void *pvParameters);

// Polls several buttons
// and sends indication about the one pressed to the display task.
void buttonTask(void *pvParameters);

#endif