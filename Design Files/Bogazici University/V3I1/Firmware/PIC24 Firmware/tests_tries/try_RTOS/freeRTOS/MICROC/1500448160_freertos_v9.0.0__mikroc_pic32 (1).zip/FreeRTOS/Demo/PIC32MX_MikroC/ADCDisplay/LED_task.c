// LED_task.c

// This file contains the LED task, which blinks LEDs.
// The functions for getting and setting blink delay and ADC value
// use semaphores to ensure thread-safe execution.

// Includes

#include "main.h"

// Memory Declarations

static uint16_t blinkDelay = 0; // LED blink delay
static uint16_t adcValue  = 0;  // ADC value to display

// Public Function Definitions

// Returns ADC value of the LED blink task. This is a thread-safe function.
uint16_t ledBlinkGetAdcValue()
{
    uint16_t tempAdcValue;
    
    xSemaphoreTake(ledBlinkSemHandle, 0xFFFFFFFFU);
    
    tempAdcValue = adcValue;
        
    xSemaphoreGive(ledBlinkSemHandle);

    return tempAdcValue;
}

// Sets ADC value of the LED blink task. This is a thread-safe function.
void ledBlinkSetAdcValue(uint16_t newAdcValue)
{
    xSemaphoreTake(ledBlinkSemHandle, 0xFFFFFFFFU);
    
    adcValue = newAdcValue;
        
    xSemaphoreGive(ledBlinkSemHandle);
}

// Returns blink delay of the LED blink task. This is a thread-safe function.
uint16_t ledBlinkGetBlinkDelay()
{
    uint16_t tempBlinkDelay;

    xSemaphoreTake(ledBlinkSemHandle, 0xFFFFFFFFU);
    
    tempBlinkDelay = blinkDelay;
        
    xSemaphoreGive(ledBlinkSemHandle);

    return tempBlinkDelay;
}

// Sets blink delay of the LED blink task. This is a thread-safe function.
void ledBlinkSetBlinkDelay(uint16_t newBlinkDelay)
{
    xSemaphoreTake(ledBlinkSemHandle, 0xFFFFFFFFU);
    
    blinkDelay = newBlinkDelay;
        
    xSemaphoreGive(ledBlinkSemHandle);
}

// Receives data from the display task and blinks LEDs accordingly.
void ledBlinkTask(void *pvParameters)
{
    uint16_t currAdcValue;
    uint16_t currblinkDelay;
    
    // Set PORTA and PORTC pins as output.
    TRISA &= 0xFF00;
    TRISC &= 0xFFE1;
    LATA = PORTA & 0xFF00;
    LATC = PORTC & 0xFFE1;
    
    // Constantly blink LEDs, displaying the ADC value.
    while (1)
    {
        // Get the current ADC value and blink delay.
        currAdcValue = ledBlinkGetAdcValue();
        currblinkDelay = ledBlinkGetBlinkDelay();
        
        // Display the ADC value.
        LATA = (PORTA & 0xFF00) | (currAdcValue & 0x00FF);
        LATC = (PORTC & 0xFFF0) | ((currAdcValue & 0x0F00) >> 7);
        
        // If there is a blink delay, turn the LEDs OFF and ON periodically.
        if (currblinkDelay > 0)
        {
            vTaskDelay(pdMS_TO_TICKS(currblinkDelay));
            LATA = PORTA & 0xFF00;
            LATC = PORTC & 0xFFE1;
            vTaskDelay(pdMS_TO_TICKS(currblinkDelay));
        }
    }
}