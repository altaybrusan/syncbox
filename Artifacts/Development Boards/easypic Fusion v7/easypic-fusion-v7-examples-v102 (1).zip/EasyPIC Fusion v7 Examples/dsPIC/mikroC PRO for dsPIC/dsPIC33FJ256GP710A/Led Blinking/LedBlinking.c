/* 
 * Project name:
     Led_Blinking (The simplest simple example)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
     Simple "Hello world" example for the world of PIC32 MCUs;
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:LED
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.0000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn ON PORTA, B, C, D, F & G LEDS at SW15. (board specific)
 */

void main() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;    // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                            // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;            // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                            // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;   // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                            // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFE;        // Set All pins as digital
  AD1PCFGH = 0xFFFF;

  TRISA = 0;                // Initialize PORTA as output
  TRISB = 0;                // Initialize PORTB as output
  TRISC = 0;                // Initialize PORTC as output
  TRISD = 0;                // Initialize PORTD as output
  TRISF = 0;                // Initialize PORTE as output
  TRISG = 0;                // Initialize PORTG as output

  LATA = 0;                 // Set PORTA to zero
  LATB = 0;                 // Set PORTB to zero
  LATC = 0;                 // Set PORTC to zero
  LATD = 0;                 // Set PORTD to zero
  LATF = 0;                 // Set PORTE to zero
  LATG = 0;                 // Set PORTG to zero

  while(1) {
    LATA = ~LATA;           // Invert PORTA value
    LATB = ~LATB;           // Invert PORTB value
    LATC = ~LATC;           // Invert PORTC value
    LATD = ~LATD;           // Invert PORTD value
    LATF = ~LATF;           // Invert PORTE value
    LATG = ~LATG;           // Invert PORTG value
    Delay_ms(1000);
  }
}