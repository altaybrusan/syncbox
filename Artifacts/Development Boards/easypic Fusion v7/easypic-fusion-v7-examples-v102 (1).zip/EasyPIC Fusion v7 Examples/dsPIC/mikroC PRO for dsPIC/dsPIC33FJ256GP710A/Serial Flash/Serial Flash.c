/* 
 * Project name:
     SerialFlash example (Demonstration of usage of the SerialFlash on-board module)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
      Demonstration of SerialFlash usage (chip erase, read Flash ID, simple writing and reading back a simple byte,
      simple writing and reading back an array of 16 bytes).
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.00000 MHz - ac:Serial_Flash
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn ON SPI control switches at SW13. (board specific)
     - Turn ON FLASH Chip Select switch at SW13.4. (board specific)
     - Turn on TFT backlight switch SW11.1. (board specific)
 */

#include <built_in.h>
#include "Serial_Flash_driver.h"
#include "resources.h"
#define _DATA_ARRAY_SIZE 16

unsigned char write_array[_DATA_ARRAY_SIZE] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
unsigned char read_array[_DATA_ARRAY_SIZE] = {0};
char cSF_test_status;

// MCU initialization
void Init() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;      // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                              // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;              // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                              // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;     // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                              // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFF;          // Set All pins as digital
  AD1PCFGH = 0xFFFF;
  
  TFT_BLED_Direction = 0;      // Set TFT backlight pin as output
  TFT_Init(320, 240);          // Initialize TFT display
  TFT_BLED = 1;                // Turn on TFT backlight
}

void DrawFrame(){
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_BLACK, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("Serial  FLASH  Example", 50, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("EasyPIC Fusion v7", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}

// Serial FLASH test
void SF_Test(char *test) {
  unsigned char temp, SerialFlashID, txt[12];
  unsigned char i, success;

  // Reset error flag
  *test = 0;

  // Erase entire flash
  TFT_Write_Text("1. Erasing chip... ", 90, 65);
  SerialFlash_ChipErase();
  TFT_Write_Text("Done!", 200, 65);

  // Read Flash ID
  SerialFlashID = SerialFlash_ReadID();
  ByteToStr(SerialFlashID, txt);
  TFT_Write_Text("2. Flash ID:", 90, 85);
  TFT_Write_Text(txt, 170, 85);
  Delay_ms(500);

  // Write and read back a single byte
  temp = 221;
  TFT_Write_Text("3. Writting:", 90, 105);
  ByteToStr(temp, txt);
  TFT_Write_Text(txt, 170, 105);
  SerialFlash_WriteByte(temp, 0x123456);

  TFT_Write_Text("4. Reading: ", 90, 125);
  temp = SerialFlash_ReadByte(0x123456);
  ByteToStr(temp, txt);
  TFT_Write_Text(txt, 170, 125);
  Delay_ms(500);

  // Write the repetitive pattern of data to fill the first 4K of memory
  // and then read the entire flash again and check the data correctness
  TFT_Write_Text("5. Writing array...", 90, 145);
  SerialFlash_WriteArray(0x0000, &write_array, _DATA_ARRAY_SIZE);
  Delay_ms(500);

  TFT_Write_Text("6. Reading array...", 90, 165);
  SerialFlash_ReadArray(0x0000, &read_array, _DATA_ARRAY_SIZE);
  Delay_ms(500);
  success = 1;

  for (i = 0; i<_DATA_ARRAY_SIZE; i++) {
    if (read_array[i] != write_array[i]) {
      success = 0;
      break;
    }
  }

  if (success) {
    TFT_Write_Text("7. Success - Full match!", 90, 185);
    *test = 1;
  }
  else {
    TFT_Write_Text("7. Failed", 90, 185);
    *test = 2;
  }
}

// Initialize SPI bus and Serial FLASH
void SF_Start() {
  //Disable other peripheral modules on the same SPI bus
  TRISG9_bit = 0;
  LATG9_bit = 1;    // Disable MMC
  TRISG12_bit = 0;
  LATG12_bit = 1;   // Disable MP3 module
  //--- initialize SPI
  SPI1_Init_Advanced(_SPI_MASTER, _SPI_8_BIT, _SPI_PRESCALE_SEC_2, _SPI_PRESCALE_PRI_1, _SPI_SS_DISABLE, _SPI_DATA_SAMPLE_END, _SPI_CLK_IDLE_LOW, _SPI_IDLE_2_ACTIVE);
  Delay_ms(100);
  SerialFlash_init();
  SerialFlash_WriteEnable();
  Delay_ms(100);
}

void main(){
  Init();
  DrawFrame();
  SF_Start();
  SF_Test(&cSF_test_status);
}