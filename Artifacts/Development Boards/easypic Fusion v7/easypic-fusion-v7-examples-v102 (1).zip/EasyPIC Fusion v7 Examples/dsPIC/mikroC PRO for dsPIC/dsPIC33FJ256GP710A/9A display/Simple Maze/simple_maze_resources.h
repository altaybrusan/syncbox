const code char Impact20x29_Regular[];
const code char Tahoma11x13_Regular[];
const code char eve_arrow_left_jpg[1629];
const code char eve_arrow_up_jpg[1613];
const code char eve_arrow_right_jpg[1667];
const code char eve_arrow_down_jpg[1659];
const code char reload__bmp[1143];
