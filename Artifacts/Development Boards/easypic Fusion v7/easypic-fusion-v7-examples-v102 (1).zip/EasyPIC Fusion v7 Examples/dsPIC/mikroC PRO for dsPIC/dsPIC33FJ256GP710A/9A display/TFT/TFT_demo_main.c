/* 
 * Project name:
     TFT_Demo
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
     This is a simple TFT display demo example.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      HS-PLL, 80.000 MHz Crystal
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on TFT backlight switch SW11.1. (board specific)
 */

#include "TFT_demo_objects.h"

void main() {
  Start_TP();
}