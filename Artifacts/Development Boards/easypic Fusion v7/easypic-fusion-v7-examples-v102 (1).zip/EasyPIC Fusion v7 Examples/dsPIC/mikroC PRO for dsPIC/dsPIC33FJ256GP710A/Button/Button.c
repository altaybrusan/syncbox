/* 
 * Project name:
     Button_Test (Sample usage of Button() function)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
     Simple demonstration on usage of the Button() function.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:Button
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on PORTB LEDs at SW15, pull-down PORTA and turn on Button Press Level
       switch SW10 for PORTA&C. (board specific)
     - Press A15 to toggle PORTB LEDs.
 */
 
unsigned int oldstate;

void main() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;      // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                              // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;              // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                              // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;     // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                              // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFF;          // Set All pins as digital
  AD1PCFGH = 0xFFFF;

  TRISA15_bit = 1;            // Set PORTA.15 pin as input

  TRISB  = 0;                 // Configure PORTB as output
  LATB = 0;                   // Initial PORTB value
  
  do {
    if (Button(&PORTA, 15, 1, 1))                   // detect logical one on RA15 pin
      oldstate = 1;
    if (oldstate && Button(&PORTA, 15, 1, 0)) {     // detect one-to-zero transition on RA15 pin
      LATB = ~LATB;                                 // invert PORTB value
      oldstate = 0;
    }
  } while(1);                                       // endless loop
}