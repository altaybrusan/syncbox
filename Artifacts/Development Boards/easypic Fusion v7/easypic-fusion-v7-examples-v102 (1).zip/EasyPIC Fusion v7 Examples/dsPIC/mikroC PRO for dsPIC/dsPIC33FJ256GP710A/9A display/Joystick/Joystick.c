/* 
 * Project name:
     Joystick
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
     This example presents features of the joystick input device.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.0000MHz - ac:Joystick
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Pull up on RA1, RA7, RA6, RA5 and RA4. (board specific)
     - Put Button Press Level switch SW10 for PORTA&C  in lower position. (board specific)
 */

#include "resources.h"

unsigned int oldstate;
unsigned int state;

void press(){
  if (Button(&PORTA, 1, 1, 1))               // detect logical one state
    oldstate = 1;
  if (oldstate && Button(&PORTA, 1, 1, 0)) { // detect logical one to logical zero transition
    TFT_Circle(160, 130, 40);
    TFT_Write_Text("Pressed", 135, 122);
    Delay_ms(300);
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
    TFT_Circle(160, 130, 40);
    TFT_Write_Text("Pressed", 135, 122);
    oldstate = 0;
    state = 1;
  }
}

void right(){
  if (Button(&PORTA, 7, 1, 1))               // detect logical one state
    oldstate = 1;
  if (oldstate && Button(&PORTA, 7, 1, 0)) { // detect logical one to logical zero transition
    TFT_Circle(223, 130, 20);
    TFT_Write_Text("Right", 207, 122);
    Delay_ms(300);
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
    TFT_Circle(223, 130, 20);
    TFT_Write_Text("Right", 207, 122);
    oldstate = 0;
    state = 2;
  }
}

void left(){
  if (Button(&PORTA, 6, 1, 1))               // detect logical one state
    oldstate = 1;
  if (oldstate && Button(&PORTA, 6, 1, 0)) { // detect logical one to logical zero transition
    TFT_Circle(97,  130, 20);
    TFT_Write_Text("Left", 85, 122);
    Delay_ms(300);
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
    TFT_Circle(97,  130, 20);
    TFT_Write_Text("Left", 85, 122);
    oldstate = 0;
    state = 3;
  }
}

void up(){
  if (Button(&PORTA, 4, 1, 1))               // detect logical one state
    oldstate = 1;
  if (oldstate && Button(&PORTA, 4, 1, 0)) { // detect logical one to logical zero transition
    TFT_Circle(160, 70, 20);
    TFT_Write_Text("Up", 153, 62);
    Delay_ms(300);
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
    TFT_Circle(160, 70, 20);
    TFT_Write_Text("Up", 153, 62);
    oldstate = 0;
    state = 4;
  }
}

void down(){
  if (Button(&PORTA, 5, 1, 1))               // detect logical one state
    oldstate = 1;
  if (oldstate && Button(&PORTA, 5, 1, 0)) { // detect logical one to logical zero transition
    TFT_Circle(160, 195, 20);
    TFT_Write_Text("Down", 143, 187);
    Delay_ms(300);
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
    TFT_Circle(160, 195, 20);
    TFT_Write_Text("Down", 143, 187);
    oldstate = 0;
    state = 5;
  }
}

void DrawFrame(){
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_BLACK, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("Press Joystick Buttons", 50, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("EasyPIC Fusion v7", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}

// MCU initialization
void Init() {

  // PLL settings
  CLKDIVbits.PLLPRE = 0;      // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                              // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;              // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                              // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;     // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                              // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFE;          // Set All pins as digital
  AD1PCFGH = 0xFFFF;
  
  TFT_BLED_Direction = 0;      // Set TFT backlight pin as output
  TFT_Set_Default_Mode();
  TFT_Init_ILI9341_8bit(320, 240);          // Initialize TFT display
  TFT_BLED = 1;                // Turn on TFT backlight
}

void main() {
  Init();                      // Initialize MCU
  DrawFrame();                 // Draw graphical frame
  
  // Set joystick buttons as input
  Joy_Up_Direction    = 1;
  Joy_Right_Direction = 1;
  Joy_Down_Direction  = 1;
  Joy_Left_Direction  = 1;
  Joy_CP_Direction    = 1;

  state = 1;

  while(1){
    TFT_Set_Pen(CL_BLACK, 1);
    TFT_Set_Font(TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
    if (oldstate && Button(&PORTA, 1, 1, 0))
      state = 1;
    if (oldstate && Button(&PORTA, 7, 1, 0))
      state = 2;
    if (oldstate && Button(&PORTA, 6, 1, 0))
      state = 3;
    if (oldstate && Button(&PORTA, 4, 1, 0))
      state = 4;
    if (oldstate && Button(&PORTA, 5, 1, 0))
      state = 5;

    switch (state){
      case 1: press(); break;
      case 2: right(); break;
      case 3: left(); break;
      case 4: up(); break;
      case 5: down(); break;
    }
  }
}