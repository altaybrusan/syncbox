const code char Tahoma11x13[];
const code char Tahoma16x19[];
const code char Image1_logo[4118];
const code char Image2_logo[3795];
