/*
 * Project name:
     I2C_Simple (Simple test of I2C library routines)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
     This program demonstrates usage of the I2C library routines. It
     establishes I2C bus communication with 24C02 EEPROM chip, writes one byte
     of data on some location, then reads it and displays it on PORTB.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7 -  ac:Serial_EEPROM
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on I2C lines at SW14.3 (RA2) amd SW14.4 (RA3). (board specific)
     - Pull-up I2C communication lines. (RA2 and RA3)
     - Turn off PORTA LEDs at SW15.1. (board specific)
     - Turn ON PORTB and PORTD LEDs on SW15.
 */
 
void EEPROM_24C02_Init() {
  I2C2_Init(100000);
}

//--------------- Writes data to 24C02 EEPROM - signle location
void EEPROM_24C02_WrSingle(unsigned short wAddr, unsigned short wData) {
  I2C2_Start();              // issue I2C start signal
  I2C2_Write(0xA0);          // send byte via I2C  (command to 24cO2)
  I2C2_Write(wAddr);         // send byte (address of EEPROM location)
  I2C2_Write(wData);         // send data (data to be written)
  I2C2_Stop();
}

//--------------- Reads data from 24C02 EEPROM - single location (random)
unsigned short EEPROM_24C02_RdSingle(unsigned short rAddr) {
  unsigned short reslt;

  I2C2_Start();              // issue I2C start signal
  I2C2_Write(0xA0);          // send byte via I2C  (device address + W)
  I2C2_Write(rAddr);         // send byte (data address)
  I2C2_Restart();            // issue I2C signal repeated start
  I2C2_Write(0xA1);          // send byte (device address + R)
  reslt = I2C2_Read(1);      // Read the data (NO acknowledge)
  I2C2_Stop();
  return reslt;
}

unsigned short i;
char varb;
void main(){
  // PLL settings
  CLKDIVbits.PLLPRE = 0;      // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                              // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;              // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                              // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;     // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                              // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFF;          // Set All pins as digital
  AD1PCFGH = 0xFFFF;

  TRISB = 0;                  // Configure PORTB as output
  TRISD = 0;                  // Configure PORTB as output
  LATB = 0;                   // Set PORTB value to zero
  LATD = 0;                   // Set PORTD value to zero

  EEPROM_24C02_Init();        // performs I2C initialization
  varb = 0x00;
  for(i = 0x00; i < 0x80; i++) {
    EEPROM_24C02_WrSingle(i,varb);
    varb++;
    delay_ms(5);
  }
  for(i = 0x00; i < 0x80; i++){
    LATD = i;
    LATB = EEPROM_24C02_RdSingle(i);
    delay_ms(100);
  }
}