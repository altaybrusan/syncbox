/*
 * Project name:
     Serial_EEPROM
 * Copyright:
     (c) Mikroelektronika, 2011.
 * Revision History:
     20110625(JK):
       - initial release;
 * Description:
     This example features the advanced communication with the 24C02 EEPROM chip
     by introducing its own library of functions for this task: init, single
     write, single and sequential read. It performs write of a sequence of bytes
     (characters) into the EEPROM and writes this out at the first row on TFT.
     Then, data read from EEPROM is performed and the result is displayed at the
     second row on TFT.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:Serial_EEPROM
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.000 MHz
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on I2C lines at SW14.5 (RA2) amd SW14.6 (RA3). (board specific)
     - Pull-up I2C communication lines (RA2 and RA3).
     - Turn off PORTA LEDs at SW15.1. (board specific)
     - Turn on TFT backlight switch SW11.1. (board specific)
 */

#include "EEPROM_24C02.h"
#include "resources.h"

char someData[14] = "I2C mikroE";
char writeData[14];
char i, tmpdata;

void Init() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;      // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                              // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;              // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                              // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;     // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                              // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFF;          // Set All pins as digital
  AD1PCFGH = 0xFFFF;
  
  TFT_BLED_Direction = 0;     // Set TFT backlight pin as output
  TFT_Set_Default_Mode();
  TFT_Init_ILI9341_8bit(320, 240);         // Initialize TFT display
  TFT_BLED = 1;               // Turn on TFT backlight
}

void DrawFrame(){
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_BLACK, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("I2C  Advanced  Example", 50, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("EasyPIC Fusion v7", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}

//  Main
void main() {
  Init();                      // Initialize MCU
  DrawFrame();                 // Draw graphical frame
  EEPROM_24C02_Init();         // performs I2C initialization

  // Example for single-byte write
  i = 0;
  tmpdata = 1;
  TFT_Write_Text("Writing Single Byte :", 50, 80);
  Delay_ms(500);
  while ((tmpdata = someData[i]) != 0) {
    i++;
    EEPROM_24C02_WrSingle(i, tmpdata);     // writes data, char by char, in the EEPROM
    Delay_ms(20);
  }
  TFT_Write_Text(someData, 190, 80);       // Display string on TFT

  EEPROM_24C02_WrSingle(i+1, 0);           // writes string termination
  Delay_ms(20);

  // Example for single-byte read
  Delay_ms(1000);
  i = 1;
  tmpdata = 1;
  TFT_Write_Text("Reading Single Byte :", 50, 100);
  Delay_ms(500);
  while ((tmpdata = EEPROM_24C02_RdSingle(i)) != 0) {  // reads data, char by char, from the EEPROM
    writeData[i] = tmpdata;
    Delay_ms(20);
    i++;
  }
  writeData[i] = 0;
  TFT_Write_Text(writeData, 190, 100);     // Display string on TFT

  //  Example for sequential data read
  Delay_ms(1000);
  EEPROM_24C02_RdSeq(1, &someData, 13);
  TFT_Write_Text("Sequential Reading :", 50, 120);
  Delay_ms(1000);
  TFT_Write_Text(someData, 190, 120);

  Delay_ms(1000);
  TFT_Write_Text("EEPROM Test Successful!", 80, 150);
}