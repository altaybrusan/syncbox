/*
 * Project name:
     Sound (Usage of Sound library)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
     This project is a simple demonstration of how to
     use sound library for playing tones on a piezo speaker.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:Sound
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.0000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on Buzzer switch SW14.8. (board specific)
     - Turn on Button Press Level switch SW10 for PORTA&C. (board specific)
     - Pull-down pins RA7...RA3 on PORTA. (board specific)
 */

void Tone1() {
  Sound_Play(659, 250);   // Frequency = 659Hz, duration = 250ms
}

void Tone2() {
  Sound_Play(698, 250);   // Frequency = 698Hz, duration = 250ms
}

void Tone3() {
  Sound_Play(784, 250);   // Frequency = 784Hz, duration = 250ms
}

void Melody() {           // Plays the melody "Yellow house"
  Tone1(); Tone2(); Tone3(); Tone3();
  Tone1(); Tone2(); Tone3(); Tone3();
  Tone1(); Tone2(); Tone3();
  Tone1(); Tone2(); Tone3(); Tone3();
  Tone1(); Tone2(); Tone3();
  Tone3(); Tone3(); Tone2(); Tone2(); Tone1();
}

void ToneA() {
  Sound_Play( 880, 50);
}
void ToneC() {
  Sound_Play(1046, 50);
}
void ToneE() {
  Sound_Play(1318, 50);
}

void Melody2() {
  unsigned short i;
  for (i = 9; i > 0; i--) {
    ToneA(); ToneC(); ToneE();
  }
}

void main() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;       // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                               // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;               // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                               // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;      // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                               // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFF;           // Set All pins as digital
  AD1PCFGH = 0xFFFF;

  TRISA  = 0xF8;               // Configure RA7..RA3 as input

  Sound_Init(&PORTD, 3);
  Sound_Play(880, 1000);       // Play sound at 880Hz for 1 second

  while (1) {
    if (Button(&PORTA,7,1,1))  // RA7 plays Tone1
      Tone1();
    while (RA7_bit) ;          // Wait for button to be released

    if (Button(&PORTA,6,1,1))  // RA6 plays Tone2
      Tone2();
    while (RA6_bit) ;          // Wait for button to be released

    if (Button(&PORTA,5,1,1))  // RA5 plays Tone3
      Tone3();
    while (RA5_bit) ;          // Wait for button to be released

    if (Button(&PORTA,4,1,1))  // RA4 plays Melody2
      Melody2();
    while (RA4_bit) ;          // Wait for button to be released

    if (Button(&PORTA,3,1,1))  // RA3 plays Melody
      Melody();
    while (RA3_bit) ;          // Wait for button to be released
  }
}