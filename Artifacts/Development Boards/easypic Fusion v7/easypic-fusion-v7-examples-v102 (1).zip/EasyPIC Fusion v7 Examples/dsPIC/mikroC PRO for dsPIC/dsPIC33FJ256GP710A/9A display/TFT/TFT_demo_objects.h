typedef struct Screen TScreen;

typedef struct  Button {
  TScreen       *OwnerScreen;
  char          Order;
  unsigned int  Left;
  unsigned int  Top;
  unsigned int  Width;
  unsigned int  Height;
  char          Pen_Width;
  unsigned int  Pen_Color;
  char          Visible;
  char          Active;
  char          Transparent;
  char          *Caption;
  const char    *FontName;
  unsigned int  Font_Color;
  char          Gradient;
  char          Gradient_Orientation;
  unsigned int  Gradient_Start_Color;
  unsigned int  Gradient_End_Color;
  unsigned int  Color;
  char          PressColEnabled;
  unsigned int  Press_Color;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TButton;

typedef struct  Button_Round {
  TScreen       *OwnerScreen;
  char          Order;
  unsigned int  Left;
  unsigned int  Top;
  unsigned int  Width;
  unsigned int  Height;
  char          Pen_Width;
  unsigned int  Pen_Color;
  char          Visible;
  char          Active;
  char          Transparent;
  char          *Caption;
  const char    *FontName;
  unsigned int  Font_Color;
  char          Gradient;
  char          Gradient_Orientation;
  unsigned int  Gradient_Start_Color;
  unsigned int  Gradient_End_Color;
  unsigned int  Color;
  char          PressColEnabled;
  unsigned int  Press_Color;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TButton_Round;

typedef struct  Label {
  char          Order;
  TScreen       *OwnerScreen;
  unsigned int  Left;
  unsigned int  Top;
  unsigned int  Width;
  unsigned int  Height;
  char          *Caption;
  const char    *FontName;
  unsigned int  Font_Pos_Ver;
  unsigned int  Font_Color;
  char          Visible;
  char          Active;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TLabel;

typedef struct  Image {
  TScreen       *OwnerScreen;
  char          Order;
  unsigned int  Left;
  unsigned int  Top;
  unsigned int  Width;
  unsigned int  Height;
  unsigned int  PictureWidth;
  unsigned int  PictureHeight;
  const char    *Picture_Name;
  char          Visible;
  char          Active;
  char          AutoSize;
  char          Picture_Type;
  char          Picture_Ratio;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TImage;

typedef struct  CircleButton {
  TScreen       *OwnerScreen;
  char          Order;
  unsigned int  Left;
  unsigned int  Top;
  unsigned int  Radius;
  char          Pen_Width;
  unsigned int  Pen_Color;
  char          Visible;
  char          Active;
  char          Transparent;
  char          *Caption;
  const char    *FontName;
  unsigned int  Font_Color;
  char          Gradient;
  char          Gradient_Orientation;
  unsigned int  Gradient_Start_Color;
  unsigned int  Gradient_End_Color;
  unsigned int  Color;
  char          PressColEnabled;
  unsigned int  Press_Color;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TCircleButton;

typedef struct  Box {
  TScreen       *OwnerScreen;
  char          Order;
  unsigned int  Left;
  unsigned int  Top;
  unsigned int  Width;
  unsigned int  Height;
  char          Pen_Width;
  unsigned int  Pen_Color;
  char          Visible;
  char          Active;
  char          Transparent;
  char          Gradient;
  char          Gradient_Orientation;
  unsigned int  Gradient_Start_Color;
  unsigned int  Gradient_End_Color;
  unsigned int  Color;
  char          PressColEnabled;
  unsigned int  Press_Color;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TBox;

typedef struct  Line {
  TScreen       *OwnerScreen;
  char          Order;
  unsigned int  First_Point_X;
  unsigned int  First_Point_Y;
  unsigned int  Second_Point_X;
  unsigned int  Second_Point_Y;
  char          Pen_Width;
  char          Visible;
  char          Active;
  unsigned int  Color;
} TLine;

struct Screen {
  unsigned int           Color;
  unsigned int           Width;
  unsigned int           Height;
  unsigned short         ObjectsCount;
  unsigned int           ButtonsCount;
  TButton                **Buttons;
  unsigned int           Buttons_RoundCount;
  TButton_Round          **Buttons_Round;
  unsigned int           LabelsCount;
  TLabel                 **Labels;
  unsigned int           ImagesCount;
  TImage                 **Images;
  unsigned int           CircleButtonsCount;
  TCircleButton          **CircleButtons;
  unsigned int           BoxesCount;
  TBox                   **Boxes;
  unsigned int           LinesCount;
  TLine                 **Lines;
};

extern   TScreen                Screen1;
extern   TLine                  Line1;
extern   TLine                  Line2;
extern   TLine                  Line3;
extern   TLine                  Line4;
extern   TLine                  Line5;
extern   TLine                  Line6;
extern   TLine                  Line7;
extern   TLine                  Line8;
extern   TLine                  Line9;
extern   TLabel                 Label1;
extern   TLine                  Line12;
extern   TLine                  Line13;
extern   TLine                  Line14;
extern   TLine                  Line15;

extern   TScreen                Screen2;
extern   TBox                   Box1;
extern   TButton                Button1;
extern   TButton_Round          ButtonRound1;
extern   TCircleButton          CircleButton1;

extern   TScreen                Screen3;
extern   TImage                 Image1;
extern   TImage                 Image2;



/////////////////////////
// Events Code Declarations
/////////////////////////

/////////////////////////////////
// Caption variables Declarations
extern char Label1_Caption[];
extern char Button1_Caption[];
extern char ButtonRound1_Caption[];
extern char CircleButton1_Caption[];
/////////////////////////////////

void DrawScreen(TScreen *aScreen);
void DrawButton(TButton *Abutton);
void DrawRoundButton(TButton_Round *Around_button);
void DrawLabel(TLabel *Alabel);
void DrawImage(TImage *Aimage);
void DrawCircleButton(TCircleButton *Acircle_button);
void DrawBox(TBox *Abox);
void DrawLine(TLine *Aline);
void Check_TP();
void Start_TP();
