/* Project name:
     ECAN_1st (CAN Network demonstration with mikroE's CAN-1 module)
 * Copyright:
     (c) MikroElektronika, 2011.
 * Revision History:
     20120823:
       - initial release (JK);
 * Description:
     This code demonstrates how to use ECAN library functions and procedures.
     It is used together with the ECAN_2nd example (on second MCU), and it can
     be used to test the connection of MCU to the CAN network.
     This node initiates the communication with the 2nd node by sending some
     data to its address. The 2nd node responds by sending back the data incre-
     mented by 1. This (1st) node then does the same and sends incremented data
     back to 2nd node, etc.
     With minor adjustments, it should work with any other MCU that has a ECAN module.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593C.pdf
     dev.board:       EasyPIC Fusion v7 : ac:CAN_port
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC30/33 and PIC24
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic30-33-and-pic24/
                      CANculator : ac:CANculator
                      http://www.libstock.com/projects/view/360/canculator
 * NOTES:
     - The indicator of good communication in this example is, that the _1st
       node always displays even data on PORTB, whilst the _2nd node always
       displays odd data.
     - Use CANculator application in order to get proper values for baud rate.
*/

#include "ECAN_Defs.h"

unsigned int Can_Send_Flags, Can_Rcv_Flags;                  // can flags
unsigned int Rx_Data_Len;                                    // received data length in bytes
char RxTx_Data[8];                                           // can rx/tx data buffer
char Msg_Rcvd;                                               // reception flag
const unsigned long ID_1st = 12111, ID_2nd = 3;              // node IDs
unsigned long Rx_ID;

/*Place/Copy this part in declaration section*/
const unsigned int SJW = 1;
const unsigned int BRP = 10;
const unsigned int PHSEG1 = 5;
const unsigned int PHSEG2 = 2;
const unsigned int PROPSEG = 8;
const unsigned int ECAN_CONFIG_FLAGS =
                                      _ECAN_CONFIG_SAMPLE_ONCE &
                                      _ECAN_CONFIG_PHSEG2_PRG_ON  &
                                      _ECAN_CONFIG_XTD_MSG        &
                                      _ECAN_CONFIG_MATCH_MSG_TYPE &
                                      _ECAN_CONFIG_LINE_FILTER_OFF;

void C2Interrupt(void) org 0x005A                            // ECAN event iterrupt
{

        IFS3bits.C2IF = 0;                                   // clear ECAN interrupt flag
        if(C2INTFbits.TBIF) {                                // was it tx interrupt?
            C2INTFbits.TBIF = 0;                             // if yes clear tx interrupt flag
  }

  if(C2INTFbits.RBIF) {                                      // was it rx interrupt?
                C2INTFbits.RBIF = 0;                         // if yes clear rx interrupt flag
        }
}

void main() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;      // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                              // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;              // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                              // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;     // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                              // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFF;          // Set All pins as digital
  AD1PCFGH = 0xFFFF;

  /* Clear Interrupt Flags */

        IFS0=0;
        IFS1=0;
        IFS2=0;
        IFS3=0;
        IFS4=0;

  /* Enable ECAN1 Interrupt */

        IEC3bits.C2IE   = 1;                       // enable ECAN1 interrupts
        C2INTEbits.TBIE = 1;                       // enable ECAN1 tx interrupt
        C2INTEbits.RBIE = 1;                       // enable ECAN1 rx interrupt

  PORTB = 0;                                       // clear PORTB
  TRISB = 0;                                       // set PORTB as output,
                                                   // for received message data displaying

  Can_Send_Flags = _ECAN_TX_PRIORITY_0 &           // form value to be used
                   _ECAN_TX_XTD_FRAME &            // with CANSendMessage
                   _ECAN_TX_NO_RTR_FRAME;

  RxTx_Data[0] = 0xFE;                              // set initial data to be sent
  ECAN2DmaChannelInit(0, 1, &ECAN2RxTxRAMBuffer);  // init dma channel 0 for
                                                   // dma to ECAN peripheral transfer
  ECAN2DmaChannelInit(2, 0, &ECAN2RxTxRAMBuffer);  // init dma channel 2 for
                                                   // ECAN peripheral to dma transfer
  /*Place/Copy this part in init section*/
  ECAN2Initialize(SJW, BRP, PHSEG1, PHSEG2, PROPSEG, ECAN_CONFIG_FLAGS);
  
  ECAN2SetBufferSize(ECAN2RAMBUFFERSIZE);          // set number of rx+tx buffers in DMA RAM

  ECAN2SelectTxBuffers(0x000F);                    // select transmit buffers
                                                   // 0x000F = buffers 0:3 are transmit buffers
  ECAN2SetOperationMode(_ECAN_MODE_CONFIG,0xFF);   // set CONFIGURATION mode

  ECAN2SetMask(_ECAN_MASK_0, -1, _ECAN_CONFIG_MATCH_MSG_TYPE & _ECAN_CONFIG_XTD_MSG);         // set all mask1 bits to ones
  ECAN2SetMask(_ECAN_MASK_1, -1, _ECAN_CONFIG_MATCH_MSG_TYPE & _ECAN_CONFIG_XTD_MSG);         // set all mask2 bits to ones
  ECAN2SetMask(_ECAN_MASK_2, -1, _ECAN_CONFIG_MATCH_MSG_TYPE & _ECAN_CONFIG_XTD_MSG);         // set all mask3 bits to ones
  ECAN2SetFilter(_ECAN_FILTER_10, ID_2nd, _ECAN_MASK_2, _ECAN_RX_BUFFER_7, _ECAN_CONFIG_XTD_MSG);  // set id of filter10 to 2nd node ID
                                                                                              // assign mask2 to filter10
                                                                                              // assign buffer7 to filter10
  ECAN2SetOperationMode(_ECAN_MODE_NORMAL, 0xFF);  // set NORMAL mode

  ECAN2Write(ID_1st, RxTx_Data, 1, Can_Send_Flags);                           // send initial message

  while (1) {                                                                 // endless loop
    Msg_Rcvd = ECAN2Read(&Rx_ID , RxTx_Data , &Rx_Data_Len, &Can_Rcv_Flags);  // receive message
    if ((Rx_ID == ID_2nd) && Msg_Rcvd) {                                      // if message received check id
      PORTB = RxTx_Data[0];                                                   // id correct, output data at PORTB
      RxTx_Data[0]++ ;                                                        // increment received data
      Delay_ms(10);
      ECAN2Write(ID_1st, RxTx_Data, 1, Can_Send_Flags);                       // send incremented data back
    }
 }
}