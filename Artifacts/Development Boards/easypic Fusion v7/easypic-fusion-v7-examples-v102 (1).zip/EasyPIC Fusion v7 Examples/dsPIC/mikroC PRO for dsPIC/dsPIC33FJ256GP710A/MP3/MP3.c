/*
 * Project name:
     MP3 (Demonstration of on-board audio module)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
     This project demonstrates communication with VS1011E mp3 codec.
     Program reads one mp3 file from MMC and sends it to VS1011E for decoding
     and playing. MMC and MP3_SCI share Hardware SPI module.
 * Test configuration:
     MCU:             P32MX795F512L
                      http://ww1.microchip.com/downloads/en/DeviceDoc/61156F.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.0000MHz
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for PIC32
                      http://www.mikroe.com/eng/categories/view/89/pic32-compilers/
 * NOTES:
     - Turn on SPI and AUDIO switches at switch SW13. (board specific)
     - Turn on microSD card switches at SW14. (board specific)
     - Turn on TFT backlight on SW11.1. (board specific)
     - Put PORTA switches in the pull-down position and turn on Button Press
       Level switch SW10 for PORTA&C.
     - Use RA1 and RA5 to increase volume for left and right channels,
       RA0 and RA1 do decrease volume for left and right channels, respecively.
     - MP3 file should have the following name : "sound.mp3".
 */

#include "MP3_routines.h"
#include "resources.h"

// MCU initialization
void Init() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;       // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                               // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;               // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                               // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;      // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                               // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFF;           // Set All pins as digital
  AD1PCFGH = 0xFFFF;
  
  TFT_BLED_Direction = 0;      // Set TFT backlight pin as output
  TFT_Init(320, 240);          // Initialize TFT display
  TFT_BLED = 1;                // Turn on TFT backlight
}

// Graphical frame
void DrawFrame(){
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_BLACK, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("Audio  MP3  Test", 80, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("EasyPIC Fusion v7", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}

void main(){
  Init();                      // Initialize MCU
  DrawFrame();                 // Draw graphical frame
  MP3_Init();                  // Start using mp3 codec
  MP3_Play();                  // Play mp3 file
}