/* 
 * Project name:
     UARTA (Usage of mikroC for PIC32 PRO UART libraries)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
     This simple example demonstrates usage of mikroC's UARTx libraries, through
     a 'loopback' interface. The data being sent to dsPIC33 through UART and sent back.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:UARTA
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.00000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn ON UARTA switches at SW12.1 and 12.2 (board specific)
 */

char uart_rd;

void main() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;          // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                                  // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;                  // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                                  // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;         // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                                  // (must be within 12.5 MHz to 80 MHz range)

  AD1PCFGL = 0xFFFF;              // Set All pins as digital
  AD1PCFGH = 0xFFFF;

  UART2_Init(56000);              // Initialize UART module at 56000 bps
  Delay_ms(100);                  // Wait for UART module to stabilize

  UART2_Write_Text("Start");
  UART2_Write(13);
  UART2_Write(10);

  while (1) {                     // Endless loop
    if (UART2_Data_Ready()) {     // If data is received
      uart_rd = UART2_Read();     // read the received data
      UART2_Write(uart_rd);       // and send data via UART
    }
  }
}