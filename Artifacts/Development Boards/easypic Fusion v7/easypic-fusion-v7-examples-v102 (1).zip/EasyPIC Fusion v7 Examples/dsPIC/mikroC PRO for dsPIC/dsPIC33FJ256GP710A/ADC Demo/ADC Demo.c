/*
 * Project name:
     ADC Demo (Display the result of ADC on LEDs)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (JK);
 * Description:
      A simple example of using the ADC library.
      ADC results are displayed on PORTA.
 * Test configuration:
     MCU:             dsPIC33FJ256GP710A
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70593d.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:ADC
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 80.0000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on PORTA LEDs on SW15. (board specific)
     - To simulate analog input on ADC channel 0, use on-board potentiometer P1
       by connecting jumper J8 (board specific) to RB0 (ADC channel 0 input).
 */
 
#include <built_in.h>

unsigned long adc_result = 0;

void main() {
  // PLL settings
  CLKDIVbits.PLLPRE = 0;      // PLLPRE<4:0> = 0  ->  N1 = 2    8MHz / 2 = 4MHz
                              // (must be within 0.8 MHz to 8 MHz range)
  PLLFBD =   38;              // PLLDIV<8:0> = 38 ->  M = 40    4MHz * 40 = 160MHz
                              // (must be within 100 MHz to 200 MHz range)
  CLKDIVbits.PLLPOST = 0;     // PLLPOST<1:0> = 0 ->  N2 = 2    160MHz / 2 = 80MHz
                              // (must be within 12.5 MHz to 80 MHz range)
  
  AD1PCFGL = 0xFFFE;          // Set PCFG0 as analog input
  AD1PCFGH = 0xFFFF;          // All other pins are digital
                              
  TRISA = 0;                  // Set PORTA as output
  TRISB0_bit = 1;             // Set PORTB.B0 as input

  ADC1_Init();                // Initialize ADC module
  Delay_ms(100);

  while(1) {
    LATA = ADC1_Get_Sample(0);   // Get ADC value from corresponding channel
    Delay_ms(50);
  }
}