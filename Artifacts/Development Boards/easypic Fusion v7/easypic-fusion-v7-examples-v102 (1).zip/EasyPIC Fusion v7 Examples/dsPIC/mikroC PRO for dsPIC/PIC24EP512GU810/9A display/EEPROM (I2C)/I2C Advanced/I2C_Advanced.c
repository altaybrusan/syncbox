/*
 * Project name:
     I2C_Advanced
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
     This example features the advanced communication with the 24C02 EEPROM chip
     by introducing its own library of functions for this task: init, single
     write, single and sequential read. It performs write of a sequence of bytes
     (characters) into the EEPROM and writes this out at the first row on TFT.
     Then, data read from EEPROM is performed and the result is displayed at the
     second row on TFT.
 * Test configuration:
     MCU:             P24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:Serial_EEPROM
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.0000MHz
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on I2C lines at SW14.3 (RA2) and SW14.4 (RA3). (board specific)
     - Turn off PORTA LEDs at SW15.1. (board specific)
     - Turn on TFT backlight switch SW11.1. (board specific)
 */

#include "EEPROM_24C02.h"
#include "resources.h"

char someData[11] = "I2C mikroE";
char writeData[10];
char i, tmpdata;

void Init() {
   // Setting output frequency to 140MHz
  PLLFBD = 70;             // PLL multiplier M=70
  CLKDIV = 0x0000;         // PLL prescaler N1=2, PLL postscaler N2=2

  ANSELA = 0x00;           // Convert all I/O pins to digital
  ANSELB = 0x00;
  ANSELC = 0x00;
  ANSELD = 0x00;
  ANSELE = 0x00;
  ANSELG = 0x00;

  TFT_BLED_Direction = 0;      // Set TFT backlight pin as output
  TFT_Set_Default_mode();
  TFT_Init_ILI9341_8bit(320, 240);          // Initialize TFT display
  TFT_BLED = 1;                // Turn on TFT backlight
}

void DrawFrame(){
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_BLACK, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("I2C  Advanced  Example", 50, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("EasyPIC Fusion v7", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}

//  Main
void main() {
  Init();                      // Initialize MCU
  DrawFrame();                 // Draw graphical frame
  EEPROM_24C02_Init();         // performs I2C initialization


  // Example for single-byte write
  i = 0;
  tmpdata = 1;
  TFT_Write_Text("Writing Single Byte :", 50, 80);
  Delay_ms(500);
  while ((tmpdata = someData[i]) != 0) {
    i++;
    EEPROM_24C02_WrSingle(i, tmpdata);     // writes data, char by char, in the EEPROM
    Delay_ms(20);
  }
  TFT_Write_Text(someData, 190, 80);       // Display string on TFT

  EEPROM_24C02_WrSingle(i+1, 0);           // writes string termination
  Delay_ms(20);

  // Example for single-byte read
  Delay_ms(1000);
  i = 1;
  tmpdata = 1;
  TFT_Write_Text("Reading Single Byte :", 50, 100);
  Delay_ms(500);
  while ((tmpdata = EEPROM_24C02_RdSingle(i)) != 0) {  // reads data, char by char, from the EEPROM
    writeData[i-1] = tmpdata;
    Delay_ms(20);
    i++;
  }
  EEPROM_24C02_WrSingle(i+1, 0);           // writes string termination
  TFT_Write_Text(writeData, 190, 100);     // Display string on TFT

  //  Example for sequential data read
  Delay_ms(1000);
  EEPROM_24C02_RdSeq(1, &someData, 13);
  TFT_Write_Text("Sequential Reading :", 50, 120);
  Delay_ms(1000);
  TFT_Write_Text(someData, 190, 120);

  Delay_ms(1000);
  TFT_Write_Text("EEPROM Test Successful!", 80, 150);
}