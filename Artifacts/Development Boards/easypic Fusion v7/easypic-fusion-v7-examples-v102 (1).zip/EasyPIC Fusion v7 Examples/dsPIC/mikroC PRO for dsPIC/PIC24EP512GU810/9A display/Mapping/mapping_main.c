/*
 * Project name:
     Mapping
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
     World map (basic info about continents).
 * Test configuration:
     MCU:             P24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.0000MHz
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on TFT backlight switch SW11.1. (board specific)
     - Turn on Touch Panel swithces at SW11. (board specific)
 */

#include "mapping_objects.h"

void main() {

  Start_TP();

  while (1) {
    Check_TP();
  }

}