/* 
 * Project name:
     Button_Test (Sample usage of Button() function)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
     Simple demonstration on usage of the Button() function.
 * Test configuration:
     MCU:             P24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:Button
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.0000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on PORTB LEDs at SW15, pull-down PORTA and turn on Button Press Level
       switch SW10 for PORTA&C. (board specific)
 */
 
unsigned int oldstate;

void main() {
  // Setting output frequency to 140MHz
  PLLFBD = 70;             // PLL multiplier M=70
  CLKDIV = 0x0000;         // PLL prescaler N1=2, PLL postscaler N2=2

  ANSELA = 0x00;           // Convert all I/O pins to digital
  ANSELB = 0x00;
  ANSELC = 0x00;
  ANSELD = 0x00;
  ANSELE = 0x00;
  ANSELG = 0x00;

  TRISA15_bit = 1;         // Set PORTA.15 pin as input

  TRISB  = 0;              // Configure PORTB as output
  LATB = 0;                // Initial PORTB value
  
  do {
    if (Button(&PORTA, 15, 1, 1))                   // detect logical one on RA15 pin
      oldstate = 1;
    if (oldstate && Button(&PORTA, 15, 1, 0)) {     // detect one-to-zero transition on RA15 pin
      LATB = ~PORTB;                                // invert PORTB value
      oldstate = 0;
    }
  } while(1);                                       // endless loop
}