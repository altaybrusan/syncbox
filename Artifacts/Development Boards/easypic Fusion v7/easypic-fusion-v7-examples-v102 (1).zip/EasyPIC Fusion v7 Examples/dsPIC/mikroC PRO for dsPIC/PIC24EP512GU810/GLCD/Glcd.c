/*
 * Project name:
     GLCD_Test (Demonstration of the GLCD library routines)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120823:
       - initial release (DO);
 * Description:
     This is a simple demonstration of the GLCD library routines:
     - Init and Clear (pattern fill)
     - Image display
     - Basic geometry - lines, circles, boxes and rectangles
     - Text display and handling
 * Test configuration:
     MCU:             PIC24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.000MHz
     Ext. Modules:    GLCD 128x64, KS108/107 controller ac:GLCD
                      http://www.mikroe.com/eng/products/view/277/various-components/
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/mikroc/dspic/
 * Notes:
     - Turn on GLCD backlight switch SW11.1.
*/

//Declarations------------------------------------------------------------------
const code char truck_bmp[1024];
//--------------------------------------------------------------end-declarations

// Glcd module connections
sbit GLCD_D0 at RE0_bit;
sbit GLCD_D1 at RE1_bit;
sbit GLCD_D2 at RE2_bit;
sbit GLCD_D3 at RE3_bit;
sbit GLCD_D4 at RE4_bit;
sbit GLCD_D5 at RE5_bit;
sbit GLCD_D6 at RE6_bit;
sbit GLCD_D7 at RE7_bit;

sbit GLCD_D0_Direction at TRISE0_bit;
sbit GLCD_D1_Direction at TRISE1_bit;
sbit GLCD_D2_Direction at TRISE2_bit;
sbit GLCD_D3_Direction at TRISE3_bit;
sbit GLCD_D4_Direction at TRISE4_bit;
sbit GLCD_D5_Direction at TRISE5_bit;
sbit GLCD_D6_Direction at TRISE6_bit;
sbit GLCD_D7_Direction at TRISE7_bit;

sbit GLCD_CS1 at LATD5_bit;
sbit GLCD_CS2 at LATD4_bit;
sbit GLCD_RS  at LATD9_bit;
sbit GLCD_RW  at LATG6_bit;
sbit GLCD_EN  at LATD10_bit;
sbit GLCD_RST at LATD7_bit;

sbit GLCD_CS1_Direction at TRISD5_bit;
sbit GLCD_CS2_Direction at TRISD4_bit;
sbit GLCD_RS_Direction  at TRISD9_bit;
sbit GLCD_RW_Direction  at TRISG6_bit;
sbit GLCD_EN_Direction  at TRISD10_bit;
sbit GLCD_RST_Direction at TRISD7_bit;
// End Glcd module connections

void delay2S(){                                  // 2 seconds delay function
  Delay_ms(2000);
}

void main() {
  unsigned short ii;
  char *someText;

  PLLFBD = 70;      // PLL multiplier M=70
  CLKDIV = 0x0000;  // PLL prescaler N1=2, PLL postscaler N2=2

  ANSELA = 0x00;    // Convert all I/O pins to digital
  ANSELB = 0x00;
  ANSELC = 0x00;
  ANSELD = 0x00;
  ANSELE = 0x00;
  ANSELG = 0x00;


  Glcd_Init();                                   // Initialize GLCD
  Glcd_Fill(0x00);                               // Clear GLCD

  while(1) {
    Glcd_Image(truck_bmp);                     // Draw image
    delay2S(); delay2S();

    Glcd_Fill(0x00);                             // Clear GLCD

    Glcd_Box(62,40,124,56,1);                    // Draw box
    Glcd_Rectangle(5,5,84,35,1);                 // Draw rectangle
    Glcd_Line(0, 0, 127, 63, 1);                 // Draw line
    delay2S();

    for(ii = 5; ii < 60; ii+=5 ){                // Draw horizontal and vertical lines
      Delay_ms(250);
      Glcd_V_Line(2, 54, ii, 1);
      Glcd_H_Line(2, 120, ii, 1);
    }

    delay2S();

    Glcd_Fill(0x00);                                       // Clear GLCD
    Glcd_Set_Font(Font_Glcd_Character8x7, 8, 7, 32);       // Choose font, see __Lib_GLCDFonts.c in Uses folder
    Glcd_Write_Text("mikroE", 1, 7, 2);                    // Write string

    for (ii = 1; ii <= 10; ii++)                           // Draw circles
      Glcd_Circle(63,32, 3*ii, 1);
    delay2S();

    Glcd_Box(12,20, 70,57, 2);                             // Draw box
    delay2S();

      Glcd_Fill(0xFF);                                     // Fill GLCD

      Glcd_Set_Font(Font_Glcd_Character8x7, 8, 7, 32);     // Change font
      someText = "8x7 Font";
      Glcd_Write_Text(someText, 5, 0, 2);                  // Write string
      delay2S();

      Glcd_Set_Font(Font_Glcd_System3x5, 3, 5, 32);        // Change font
      someText = "3X5 CAPITALS ONLY";
      Glcd_Write_Text(someText, 60, 2, 2);                 // Write string
      delay2S();

      Glcd_Set_Font(Font_Glcd_System5x7, 5, 7, 32);        // Change font
      someText = "5x7 Font";
      Glcd_Write_Text(someText, 5, 4, 2);                  // Write string
      delay2S();

      Glcd_Set_Font(Font_Glcd_5x7, 5, 7, 32);              // Change font
      someText = "5x7 Font (v2)";
      Glcd_Write_Text(someText, 50, 6, 2);                 // Write string
      delay2S();
  }
}