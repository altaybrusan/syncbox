/* 
 * Project name:
     LM35 (analog on-board temperature sensor)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
     This example utilizes temperature sensor on EasyPIC Fusion V7 board. Temperature (in form of
     ADC value) is read from temperature pin RB0/AN0 and then converted, using exact formula,
     to Celsius degrees format. Value is then displayed on TFT display.
 * Test configuration:
     MCU:             P24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:LM35
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.0000MHz
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on LM35 switch at SW11.4. (board specific)
     - Turn on TFT backlight switch SW11.1. (board specific)
     - Turn off PORTB LEDs at SW15. (board specific)
 */

#include "resources.h"

const unsigned long VREF = 3300;   // Voltage reference in mV
char txt[15] = "000.0   C";

void Init() {
  // Setting output frequency to 140MHz
  PLLFBD = 70;             // PLL multiplier M=70
  CLKDIV = 0x0000;         // PLL prescaler N1=2, PLL postscaler N2=2

  ANSELA = 0x00;           // Convert all I/O pins to digital
  ANSELB = 0x01;
  ANSELC = 0x00;
  ANSELD = 0x00;
  ANSELE = 0x00;
  ANSELG = 0x00;
  TFT_BLED_Direction = 0;      // Set TFT backlight pin as output
  TFT_Set_Default_mode();
  TFT_Init_ILI9341_8bit(320, 240);          // Initialize TFT display
  TFT_BLED = 1;                // Turn on TFT backlight
  TRISB0_bit = 1;              // Set PORTB.B0 as input
}

void DrawFrame(){
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_BLACK, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("Temperature  Sensor  (LM35)", 27, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("EasyPIC Fusion v7", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}


void Display_Temperature(unsigned long temp_mV) {
  ByteToStr(temp_mV/10, txt);
  txt[3] = '.';
  txt[4] = temp_mV % 10 + 48;
  txt[7] = 176;

  // Print temperature on TFT
  TFT_Set_Brush(1,CL_WHITE,0,0,0,0);
  TFT_Set_Pen(CL_WHITE,1);
  TFT_Rectangle(85,100,200,140);
  TFT_Set_Font(&tahoma29x29_Bold, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text(txt, 85, 100);
}

void main() {
  unsigned long temp;

  Init();
  DrawFrame();

  TFT_Set_Font(&tahoma29x29_Bold, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("Temperature:  ", 75, 65);

  ADC1_Init();                 // Initialize ADC

  do {
    temp = ADC1_Get_Sample(0);
    temp = (temp * VREF) / 1024;
    Display_Temperature(temp);
    Delay_ms(1000);
  } while(1);
}