/*
 * Project name:
     Led_Curtain (The simplest simple example)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
     Simple "Hello world" example for the world of PIC24 MCUs;
 * Test configuration:
     MCU:             P24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:LED
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.0000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn ON PORTA, B, C, D, F & G LEDS at SW15. (board specific)
 */

char counter;

void wait() {
  Delay_ms(100);
}

void main() {
  // Setting output frequency to 140MHz
  PLLFBD = 70;        // PLL multiplier M=70
  CLKDIV = 0x0000;    // PLL prescaler N1=2, PLL postscaler N2=2

  ANSELA = 0x00;      // Convert all I/O pins to digital
  ANSELB = 0x00;
  ANSELC = 0x00;
  ANSELD = 0x00;
  ANSELE = 0x00;
  ANSELG = 0x00;

  TRISA = 0;          // set direction to be output
  TRISB = 0;          // set direction to be output
  TRISC = 0;          // set direction to be output
  TRISD = 0;          // set direction to be output
  TRISE = 0;          // set direction to be output
  TRISF = 0;          // set direction to be output
  TRISG = 0;          // set direction to be output


  LATA = 0;           // turn OFF the LATA leds
  LATB = 0;           // turn OFF the LATB leds
  LATC = 0;           // turn OFF the LATC leds
  LATD = 0;           // turn OFF the LATD leds
  LATE = 0;           // turn OFF the LATE leds
  LATF = 0;           // turn OFF the LATF leds
  LATG = 0;           // turn OFF the LATG leds

  counter = 0;
  while(1) {
    // TURN ON LEDs
    for (counter = 0; counter < 4; counter++){
      LATA |= 0x8888 >> counter;
      LATB |= 0x8888 >> counter;
      LATC |= 0x8888 >> counter;
      LATD |= 0x8888 >> counter;
      LATE |= 0x8888 >> counter;
      LATF |= 0x8888 >> counter;
      LATG |= 0x8888 >> counter;
      Delay_ms(100);
    }
    // TURN OFF LEDs
    for (counter = 0; counter < 4; counter++){
      LATA &= 0x7777 >> counter;
      LATB &= 0x7777 >> counter;
      LATC &= 0x7777 >> counter;
      LATD &= 0x7777 >> counter;
      LATE &= 0x7777 >> counter;
      LATF &= 0x7777 >> counter;
      LATG &= 0x7777 >> counter;
      Delay_ms(100);
    }
  }
}