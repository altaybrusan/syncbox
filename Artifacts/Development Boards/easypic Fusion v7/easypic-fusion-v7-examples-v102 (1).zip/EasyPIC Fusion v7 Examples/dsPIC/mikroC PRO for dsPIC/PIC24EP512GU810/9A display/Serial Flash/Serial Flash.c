/* 
 * Project name:
     SerialFlash example (Demonstration of usage of the SerialFlash on-board module)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
      Demonstration of SerialFlash usage (chip erase, read Flash ID, simple writing and reading back a simple byte,
      simple writing and reading back an array of 16 bytes).
 * Test configuration:
     MCU:             P24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:Serial_Flash
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.0000MHz
     Ext. Modules:    EasyTFT display - ac:EasyTFT
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn ON SPI control switches at SW13. (board specific)
     - Turn ON FLASH Chip Select switch at SW13.4. (board specific)
     - Turn on TFT backlight switch SW11.1. (board specific)
 */

#include <built_in.h>
#include "Serial_Flash_driver.h"
#include "resources.h"
#define _DATA_ARRAY_SIZE 16

unsigned char write_array[_DATA_ARRAY_SIZE] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
unsigned char read_array[_DATA_ARRAY_SIZE] = {0};
char cSF_test_status;

// MCU initialization
void Init() {
  // Setting output frequency to 140MHz
  PLLFBD = 70;             // PLL multiplier M=70
  CLKDIV = 0x0000;         // PLL prescaler N1=2, PLL postscaler N2=2

  ANSELA = 0x00;           // Convert all I/O pins to digital
  ANSELB = 0x00;
  ANSELC = 0x00;
  ANSELD = 0x00;
  ANSELE = 0x00;
  ANSELG = 0x00;
  TFT_BLED_Direction = 0;      // Set TFT backlight pin as output
  TFT_Set_Default_mode();
  TFT_Init_ILI9341_8bit(320, 240);          // Initialize TFT display
  TFT_BLED = 1;                // Turn on TFT backlight
}

void DrawFrame(){
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_BLACK, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("Serial  FLASH  Example", 50, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("EasyPIC Fusion v7", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}

// Serial FLASH test
void SF_Test(char *test) {
  unsigned char temp, SerialFlashID, txt[12];
  unsigned char i, success;

  // Reset error flag
  *test = 0;

  // Erase entire flash
  TFT_Write_Text("1. Erasing chip... ", 90, 65);
  SerialFlash_ChipErase();
  TFT_Write_Text("Done!", 200, 65);

  // Read Flash ID
  SerialFlashID = SerialFlash_ReadID();
  ByteToStr(SerialFlashID, txt);
  TFT_Write_Text("2. Flash ID:", 90, 85);
  TFT_Write_Text(txt, 170, 85);
  Delay_ms(500);

  // Write and read back a single byte
  temp = 221;
  TFT_Write_Text("3. Writting:", 90, 105);
  ByteToStr(temp, txt);
  TFT_Write_Text(txt, 170, 105);
  SerialFlash_WriteByte(temp, 0x123456);

  TFT_Write_Text("4. Reading: ", 90, 125);
  temp = SerialFlash_ReadByte(0x123456);
  ByteToStr(temp, txt);
  TFT_Write_Text(txt, 170, 125);
  Delay_ms(500);

  // Write the repetitive pattern of data to fill the first 4K of memory
  // and then read the entire flash again and check the data correctness
  TFT_Write_Text("5. Writing array...", 90, 145);
  SerialFlash_WriteArray(0x0000, &write_array, _DATA_ARRAY_SIZE);
  Delay_ms(500);

  TFT_Write_Text("6. Reading array...", 90, 165);
  SerialFlash_ReadArray(0x0000, &read_array, _DATA_ARRAY_SIZE);
  Delay_ms(500);
  success = 1;

  for (i = 0; i<_DATA_ARRAY_SIZE; i++) {
    if (read_array[i] != write_array[i]) {
      success = 0;
      break;
    }
  }

  if (success) {
    TFT_Write_Text("7. Success - Full match!", 90, 185);
    *test = 1;
  }
  else {
    TFT_Write_Text("7. Failed", 90, 185);
    *test = 2;
  }
}

// Initialize SPI bus and Serial FLASH
void SF_Start() {
  PPS_Mapping(104, _OUTPUT,  _SDO3);             // Sets pin RP104 to be Output, and maps SD03 to it
  PPS_Mapping(98, _INPUT, _SDI3);                // Sets pin RP98 to be Input, and maps SD01 to it
  PPS_Mapping(79, _OUTPUT, _SCK3OUT);            // Sets pin RP79 to be Output, and maps SCK3 to it

  // Initialize SPI3 module
  // master_mode    = _SPI_MASTER
  // data_mode      = _SPI_8_BIT
  // sec. prescaler = _SPI_PRESCALE_SEC_4
  // pri. prescaler = _SPI_PRESCALE_PRI_16
  // slave_select   = _SPI_SS_DISABLE (Only for slave mod)
  // data_sample    = _SPI_DATA_SAMPLE_END
  // clock_idle     = _SPI_CLK_IDLE_HIGH
  // edge           = _SPI_ACTIVE_2_IDLE
  SPI3_Init_Advanced(_SPI_MASTER,
                     _SPI_8_BIT,
                     _SPI_PRESCALE_SEC_4,
                     _SPI_PRESCALE_PRI_16,
                     _SPI_SS_DISABLE,
                     _SPI_DATA_SAMPLE_END,
                     _SPI_CLK_IDLE_HIGH,
                     _SPI_ACTIVE_2_IDLE);
  Delay_ms(100);
  SerialFlash_init();
  SerialFlash_WriteEnable();
  Delay_ms(100);
}

void main(){
  Init();
  DrawFrame();
  SF_Start();
  SF_Test(&cSF_test_status);
}