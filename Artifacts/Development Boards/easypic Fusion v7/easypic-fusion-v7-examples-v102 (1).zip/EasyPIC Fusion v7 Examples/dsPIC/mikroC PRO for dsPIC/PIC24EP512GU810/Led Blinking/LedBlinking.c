/* 
 * Project name:
     Led_Blinking (The simplest simple example)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
     Simple "Hello world" example for the world of PIC24 MCUs;
 * Test configuration:
     MCU:             P24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:LED
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.0000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn ON PORTA, B, C, D, F & G LEDS at SW15. (board specific)
 */

void main() {
  // Setting output frequency to 140MHz
  PLLFBD = 70;           // PLL multiplier M=70
  CLKDIV = 0x0000;       // PLL prescaler N1=2, PLL postscaler N2=2

  ANSELA = 0x00;         // Convert all I/O pins to digital
  ANSELB = 0x00;
  ANSELC = 0x00;
  ANSELD = 0x00;
  ANSELE = 0x00;
  ANSELG = 0x00;

  TRISA = 0;             // Initialize PORTA as output
  TRISB = 0;             // Initialize PORTB as output
  TRISC = 0;             // Initialize PORTC as output
  TRISD = 0;             // Initialize PORTD as output
  TRISF = 0;             // Initialize PORTE as output
  TRISG = 0;             // Initialize PORTG as output

  LATA = 0;              // Set PORTA to zero
  LATB = 0;              // Set PORTB to zero
  LATC = 0;              // Set PORTC to zero
  LATD = 0;              // Set PORTD to zero
  LATF = 0;              // Set PORTE to zero
  LATG = 0;              // Set PORTG to zero

  while(1) {
    LATA = ~PORTA;       // Invert PORTA value
    LATB = ~PORTB;       // Invert PORTB value
    LATC = ~PORTC;       // Invert PORTC value
    LATD = ~PORTD;       // Invert PORTD value
    LATF = ~PORTF;       // Invert PORTE value
    LATG = ~PORTG;       // Invert PORTG value
    Delay_ms(1000);
  }
}