/*
 * Project name:
     ADC Demo (Display the result of ADC on LEDs)
 * Copyright:
     (c) Mikroelektronika, 2012.
 * Revision History:
     20120810:
       - initial release (FJ);
 * Description:
      A simple example of using the ADC library.
      ADC results are displayed on PORTA.
 * Test configuration:
     MCU:             P24EP512GU810
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70616F.pdf
     Dev.Board:       EasyPIC Fusion v7 - ac:ADC
                      http://www.mikroe.com/easypic-fusion/
     Oscillator:      XT-PLL, 140.0000MHz
     Ext. Modules:    None.
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic/
 * NOTES:
     - Turn on PORTA LEDs on SW15. (board specific)
     - To simulate analog input on ADC channel 0, use on-board potentiometer P1
       by connecting jumper J8 (board specific) to RB0 (ADC channel 0 input).
 */
 
#include <built_in.h>

unsigned long adc_result = 0;

void main() {
  // Setting output frequency to 140MHz
  PLLFBD = 70;             // PLL multiplier M=70
  CLKDIV = 0x0000;         // PLL prescaler N1=2, PLL postscaler N2=2

  ANSELA = 0x00;           // Convert all I/O pins to digital
  ANSELB = 0x01;
  ANSELC = 0x00;
  ANSELD = 0x00;
  ANSELE = 0x00;
  ANSELG = 0x00;

  TRISA = 0;               // Set PORTA as output
  TRISB0_bit = 1;          // Set PORTB.B0 as input

  ADC1_Init();             // Initialize ADC module
  Delay_ms(100);

  while(1) {
    LATA = ADC1_Get_Sample(0);   // Get ADC value from corresponding channel
    Delay_ms(50);
  }
}